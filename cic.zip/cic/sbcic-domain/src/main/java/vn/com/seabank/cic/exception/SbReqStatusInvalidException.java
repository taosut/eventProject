package vn.com.seabank.cic.exception;

import vn.com.seabank.core.exception.ServiceBadException;

public class SbReqStatusInvalidException extends ServiceBadException {

    public SbReqStatusInvalidException(String status) {
        super(String.format("status is invalid. %s", status));
    }

    @Override
    public String getErrorCode() {
        return "sb_req_status_invalid";
    }
}
