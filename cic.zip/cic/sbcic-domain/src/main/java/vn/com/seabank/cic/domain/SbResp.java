package vn.com.seabank.cic.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.util.DigestUtils;
import vn.com.seabank.cic.exception.SbRespSyncStatusInvalidException;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "sb_resps")
public class SbResp {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    Long id;

    @Column(name = "content_")
    String content;

    @Column(name = "content_hash")
    String contentHash;

    @Column(name = "created_time")
    @Temporal(value = TemporalType.TIMESTAMP)
    @CreatedDate
    Date createdTime;

    @Column(name = "sync_time")
    @Temporal(value = TemporalType.TIMESTAMP)
    Date syncTime;

    @Column(name = "sync_retry")
    Integer syncRetry;

    @Column(name = "sync_status")
    String syncStatus;


    @ManyToOne(optional = false, fetch=FetchType.LAZY)
    @JoinColumn(name = "sb_reqs_id", referencedColumnName = "id")
    SbReq sbReq;

    @PrePersist
    public void prePersist(){
        this.contentHash = this.content == null ? null : DigestUtils.md5DigestAsHex(this.content.getBytes());
        this.createdTime = this.createdTime == null ? Calendar.getInstance().getTime() : this.createdTime;

    }

    public enum SyncStatus {
        NOT_SYNC, WAIT_CONFIRM, SYNC_ERR, SYNCED;

        static public SyncStatus find(String value) {
            for (SyncStatus item : SyncStatus.values()) {
                if ( item.name().equalsIgnoreCase(value) ) return item;
            }
            throw new SbRespSyncStatusInvalidException(value);
        }
    }


    @Override
    public String toString() {
        return "SbResp{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", contentHash='" + contentHash + '\'' +
                ", createdTime=" + createdTime +
                ", syncTime=" + syncTime +
                ", syncRetry=" + syncRetry +
                ", syncStatus='" + syncStatus + '\'' +
                '}';
    }
}
