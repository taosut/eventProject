package vn.com.seabank.cic.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.util.DigestUtils;
import vn.com.seabank.cic.exception.SbReqStatusInvalidException;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "sb_reqs")
public class SbReq {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    Long id;

    @Column(name = "trace_id")
    String traceId;

    @Column(name = "product_code")
    String productCode;

    @Column(name = "content_")
    String content;

    @Column(name = "content_hash")
    String contentHash;

    @Column(name = "transaction_id")
    Long transactionId;

    @Column(name = "created_time")
    @Temporal(value = TemporalType.TIMESTAMP)
    @CreatedDate
    Date createdTime;

    @Column(name = "status")
    String status;

    @OneToMany(mappedBy="sbReq",fetch = FetchType.LAZY)
    List<SbResp> sbResps;

    @PrePersist
    public void prePersist(){
        this.contentHash = this.content == null ? null : DigestUtils.md5DigestAsHex(this.content.getBytes());
        this.createdTime = this.createdTime == null ? Calendar.getInstance().getTime() : this.createdTime;

    }

    public enum Status {
        CREATED, WAITING, COMPLETED, ERROR;

        static public Status find(String value) {
            for (Status item : Status.values()) {
                if ( item.name().equalsIgnoreCase(value) ) return item;
            }
            throw new SbReqStatusInvalidException(value);
        }
    }

    @Override
    public String toString() {
        return "SbReq{" +
                "id=" + id +
                ", traceId='" + traceId + '\'' +
                ", productCode='" + productCode + '\'' +
                ", content='" + content + '\'' +
                ", contentHash='" + contentHash + '\'' +
                ", transactionId=" + transactionId +
                ", createdTime=" + createdTime +
                ", status='" + status + '\'' +
                '}';
    }
}
