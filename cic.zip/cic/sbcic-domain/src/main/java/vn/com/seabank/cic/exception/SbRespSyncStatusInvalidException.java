package vn.com.seabank.cic.exception;

import vn.com.seabank.core.exception.ServiceBadException;

public class SbRespSyncStatusInvalidException extends ServiceBadException {

    public SbRespSyncStatusInvalidException(String status) {
        super(String.format("sync status is invalid. %s", status));
    }

    @Override
    public String getErrorCode() {
        return "sb_resp_sync_status_invalid";
    }
}
