CREATE TABLE sb_reqs (
  id             BIGSERIAL NOT NULL,
  trace_id       varchar(255) UNIQUE,
  product_code   varchar(255) NOT NULL,
  content_       text NOT NULL,
  content_hash   varchar(255),
  transaction_id int8,
  created_time   timestamp NOT NULL,
  status         varchar(50) NOT NULL,
  PRIMARY KEY (id));
COMMENT ON COLUMN sb_reqs.trace_id IS 'trace ID từ bank gửi sang CIC Gateway';
COMMENT ON COLUMN sb_reqs.product_code IS 'Mã gói sản phẩn truy vấn';
COMMENT ON COLUMN sb_reqs.content_ IS 'Nội dung Request (Message content khi MQ, Request Body khi HTTP)';
COMMENT ON COLUMN sb_reqs.transaction_id IS 'Mã giao dịch ghi nhận phía CIC';
COMMENT ON COLUMN sb_reqs.status IS 'CREATED|WAITING|COMPLETE|ERROR trạng thái của Request';

CREATE TABLE sb_resps (
  id           BIGSERIAL NOT NULL,
  sb_reqs_id   int8 NOT NULL,
  content_     text,
  content_hash varchar(255),
  sync_time    timestamp,
  sync_retry   int4 DEFAULT 0,
  sync_status  varchar(50) NOT NULL,
  created_time timestamp NOT NULL,
  PRIMARY KEY (id));
COMMENT ON COLUMN sb_resps.content_ IS 'Nội dung bản tin CIC trả lời, dạng text';
COMMENT ON COLUMN sb_resps.sync_time IS 'thời gian thực hiện đồng bộ';
COMMENT ON COLUMN sb_resps.sync_retry IS '0|N số lần retry khi sync, default 0';
COMMENT ON COLUMN sb_resps.sync_status IS 'NOT_SYNC|SYNC_ERR|SYNCED trạng thái đồng bộ bản tin trả lời từ CIC về Bank';
ALTER TABLE sb_resps ADD CONSTRAINT FKsb_resps304934 FOREIGN KEY (sb_reqs_id) REFERENCES sb_reqs (id);
