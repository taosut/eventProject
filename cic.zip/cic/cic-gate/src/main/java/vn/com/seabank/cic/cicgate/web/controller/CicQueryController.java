package vn.com.seabank.cic.cicgate.web.controller;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.com.seabank.cic.cicgate.service.CicQueryService;
import vn.com.seabank.cic.cicgate.service.sout.CreateCicQueryOut;
import vn.com.seabank.cic.cicgate.web.converter.CreateCicQueryInConverter;
import vn.com.seabank.cic.cicgate.web.converter.CreateCicQueryResponseConverter;
import vn.com.seabank.cic.cicgate.web.request.CreateCicQueryRequest;
import vn.com.seabank.cic.cicgate.ws.CicWsGateway;
import vn.com.seabank.cic.exception.CicUnauthenticated;

import javax.validation.Valid;

@Slf4j
@RestController
//@RequestMapping(value = "cic")
@Api(tags = "Cic Gate")
public class CicQueryController {

    @Autowired
    CicWsGateway cicWsGateway;

    @Autowired
    CicQueryService cicQueryService;


    @PostMapping(value = "query")
    public ResponseEntity<?> createCicQuery(
            @Valid @RequestBody CreateCicQueryRequest createCicQueryRequest
    ){
        // check CIC SOAP authenticate
        if(cicWsGateway.login("user1", "pass1")){
            CreateCicQueryOut createCicQueryOut = cicQueryService.createCicQueryRequest(
                    new CreateCicQueryInConverter().apply(createCicQueryRequest)
            );
            // enrich
            createCicQueryOut.setTraceId(createCicQueryRequest.getTraceId());

            log.info("create query request success ... #{}", createCicQueryOut);
            return ResponseEntity.ok(new CreateCicQueryResponseConverter().apply(createCicQueryOut));
        }
        log.warn("soap authenticate error ... #{}", createCicQueryRequest);
        // unauthenticated
        throw new CicUnauthenticated("soap login error");
    }


}
