package vn.com.seabank.cic.cicgate.ws;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import vn.com.seabank.cic.cicgate.ws.client.LoginRequest;
import vn.com.seabank.cic.cicgate.ws.client.LoginResponse;

@Slf4j
public class CicWsGateway extends WebServiceGatewaySupport {


   public boolean login(String username, String password) {

        LoginRequest request = new LoginRequest();
        request.setUsername(username);
        request.setPassword(password);
        //
        LoginResponse response = (LoginResponse) getWebServiceTemplate().marshalSendAndReceive(request);
       log.info("cic login ... #{},{}" , username, response.isAuthenticated());
        return response.isAuthenticated();
    }
}
