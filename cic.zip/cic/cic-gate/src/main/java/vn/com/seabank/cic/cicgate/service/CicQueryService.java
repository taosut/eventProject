package vn.com.seabank.cic.cicgate.service;


import vn.com.seabank.cic.cicgate.service.sin.CreateCicQueryIn;
import vn.com.seabank.cic.cicgate.service.sout.CreateCicQueryOut;

public interface CicQueryService {

    CreateCicQueryOut createCicQueryRequest(CreateCicQueryIn createCicQueryIn);

}
