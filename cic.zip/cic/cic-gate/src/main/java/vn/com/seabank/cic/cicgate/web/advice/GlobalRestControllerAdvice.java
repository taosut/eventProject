package vn.com.seabank.cic.cicgate.web.advice;

import org.springframework.web.bind.annotation.RestControllerAdvice;
import vn.com.seabank.web.advice.ResponseEntityExceptionHandler;


@RestControllerAdvice
public class GlobalRestControllerAdvice extends ResponseEntityExceptionHandler {

}
