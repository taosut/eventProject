package vn.com.seabank.cic.cicgate.service.converter;

import vn.com.seabank.cic.cicgate.service.sout.CreateCicQueryOut;
import vn.com.seabank.cic.domain.CicIn;

import java.util.function.Function;

public class CreateCicQueryRequestOutConverter implements Function<CicIn, CreateCicQueryOut> {

    @Override
    public CreateCicQueryOut apply(CicIn cicIn) {
     return CreateCicQueryOut.builder()
             .id(cicIn.getId())
             .build();

    }
}
