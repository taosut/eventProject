package vn.com.seabank.cic.cicgate.web.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class CreateCicQueryRequest {

    @JsonProperty(value = "trace_id")
    @NotBlank(message = "trace_id is required")
    String traceId;


    @JsonProperty(value = "product_code")
    @NotBlank(message = "product_code is required")
    String productCode;

    @JsonProperty(value = "content")
    @NotBlank(message = "content is required")
    String content;



}
