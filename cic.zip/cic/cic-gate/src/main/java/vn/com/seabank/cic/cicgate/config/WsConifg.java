package vn.com.seabank.cic.cicgate.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import vn.com.seabank.cic.cicgate.ws.CicWsGateway;

@Configuration
public class WsConifg {

    @Value("${cic.cic-gate.uri:http://127.0.0.1:9200/ws/cicQuery}")
    String cicWsUri;

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        // this package must match the package in the <generatePackage> specified in
        // pom.xml
        marshaller.setContextPath("vn.com.seabank.cic.cicgate.ws.client");
        return marshaller;
    }

    @Bean
    public CicWsGateway cicWsGateway(Jaxb2Marshaller marshaller) {
        CicWsGateway client = new CicWsGateway();
//        client.setDefaultUri("http://127.0.0.1:9200/ws/cicQuery");
        client.setDefaultUri(this.cicWsUri);
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        return client;
    }

}
