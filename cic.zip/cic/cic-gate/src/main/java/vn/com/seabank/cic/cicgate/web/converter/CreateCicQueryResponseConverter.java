package vn.com.seabank.cic.cicgate.web.converter;

import vn.com.seabank.cic.cicgate.service.sout.CreateCicQueryOut;
import vn.com.seabank.cic.cicgate.web.response.CreateCicQueryResponse;

import java.util.function.Function;


public class CreateCicQueryResponseConverter implements Function<CreateCicQueryOut, CreateCicQueryResponse> {


    @Override
    public CreateCicQueryResponse apply(CreateCicQueryOut createCicQueryOut) {
        return CreateCicQueryResponse.builder()
                .id(createCicQueryOut.getId())
                .traceId(createCicQueryOut.getTraceId())
                .build();

    }
}
