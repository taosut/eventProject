package vn.com.seabank.cic.cicgate.service.sin;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@ToString
@Builder
public class CreateCicQueryIn {

    String traceId;
    String productCode;
    String content;

}
