package vn.com.seabank.cic.cicgate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.domain.CicIn;

import java.util.Optional;

public interface CicInRepository extends JpaRepository<CicIn, Long> {

//    Optional<CicIn> findFirstByMaCic(String maCic);
}
