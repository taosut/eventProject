package vn.com.seabank.cic.cicgate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan("vn.com.seabank.cic.domain")
public class CicGateApplication {

	public static void main(String[] args) {
		SpringApplication.run(CicGateApplication.class, args);
	}
}
