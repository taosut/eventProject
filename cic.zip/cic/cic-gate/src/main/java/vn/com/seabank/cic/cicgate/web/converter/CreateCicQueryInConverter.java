package vn.com.seabank.cic.cicgate.web.converter;

import vn.com.seabank.cic.cicgate.service.sin.CreateCicQueryIn;
import vn.com.seabank.cic.cicgate.web.request.CreateCicQueryRequest;

import java.util.function.Function;

public class CreateCicQueryInConverter implements Function<CreateCicQueryRequest, CreateCicQueryIn> {

    @Override
    public CreateCicQueryIn apply(CreateCicQueryRequest createCicQueryRequest) {
      return CreateCicQueryIn.builder()
              .traceId(createCicQueryRequest.getTraceId())
              .productCode(createCicQueryRequest.getProductCode())
              .content(createCicQueryRequest.getContent())
              .build();

    }
}
