package vn.com.seabank.cic.cicgate.service.sout;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
public class CreateCicQueryOut {

    // req info
    long id;
    String traceId;
//    String content;


}
