package vn.com.seabank.cic.cicgate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.domain.CicOut;

public interface CicOutRepository extends JpaRepository<CicOut, Long> {
}
