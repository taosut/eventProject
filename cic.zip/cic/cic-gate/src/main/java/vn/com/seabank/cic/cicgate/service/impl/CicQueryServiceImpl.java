package vn.com.seabank.cic.cicgate.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.cicgate.repository.CicInRepository;
import vn.com.seabank.cic.cicgate.service.CicQueryService;
import vn.com.seabank.cic.cicgate.service.converter.CreateCicQueryRequestOutConverter;
import vn.com.seabank.cic.cicgate.service.sin.CreateCicQueryIn;
import vn.com.seabank.cic.cicgate.service.sout.CreateCicQueryOut;
import vn.com.seabank.cic.domain.CicIn;

import java.util.Optional;

@Slf4j
@Service
@Transactional
public class CicQueryServiceImpl implements CicQueryService {

    @Autowired
    CicInRepository cicInRepository;

    @Override
    @Transactional(propagation =  Propagation.REQUIRED)
    public CreateCicQueryOut createCicQueryRequest(CreateCicQueryIn createCicQueryIn) {
        log.info("create query request ... #{}", createCicQueryIn);
                // make new record for query request
        String content = createCicQueryIn.getContent();
        // content parsing ( form json/xml to fields, eg ma_cic, cmnd ...

        //
        CicIn cicIn = new CicIn();
        // set ...
        cicIn.setMaSp(createCicQueryIn.getProductCode());
        cicIn.setTt(Integer.valueOf(0));  // pending for process

        cicInRepository.save(cicIn);
        return new CreateCicQueryRequestOutConverter().apply(cicIn);
    }

}
