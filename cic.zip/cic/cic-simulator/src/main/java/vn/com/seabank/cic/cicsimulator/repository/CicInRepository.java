package vn.com.seabank.cic.cicsimulator.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.domain.CicIn;

import java.util.List;
import java.util.Optional;

public interface CicInRepository extends JpaRepository<CicIn, Long> {

    List<CicIn> findTop10ByTt(int tt);

}
