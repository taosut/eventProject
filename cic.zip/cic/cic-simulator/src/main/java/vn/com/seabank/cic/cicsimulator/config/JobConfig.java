package vn.com.seabank.cic.cicsimulator.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import vn.com.seabank.cic.cicsimulator.job.CicQueryJob;

@Configuration
@EnableScheduling
public class JobConfig {

    @Bean
    public CicQueryJob cicQueryProcess(){
        return new CicQueryJob();
    }

}
