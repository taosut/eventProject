package vn.com.seabank.cic.cicsimulator.ws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import java.util.concurrent.atomic.AtomicInteger;

@Endpoint
public class CicQueryWsEndpoint {

    public static final String NAMESPACE_URI = "http://seabank.com.vn";

    static Logger logger = LoggerFactory.getLogger(CicQueryWsEndpoint.class);

    static AtomicInteger atomicInteger = new AtomicInteger(0);

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "loginRequest")
    @ResponsePayload
    public LoginResponse login(@RequestPayload LoginRequest request) {
        //
        int counter = atomicInteger.incrementAndGet();

        logger.info("#{} login ... {}", counter, request.getUsername());
        //
        LoginResponse loginResponse = new LoginResponse();
//        loginResponse.setAuthenticated(counter%2 == 0 ? true : false);
        loginResponse.setAuthenticated(true);
        //
        return loginResponse;
    }
}
