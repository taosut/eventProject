package vn.com.seabank.cic.cicsimulator.job;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.cicsimulator.repository.CicInRepository;
import vn.com.seabank.cic.cicsimulator.repository.CicOutRepository;
import vn.com.seabank.cic.domain.CicIn;
import vn.com.seabank.cic.domain.CicOut;

import java.util.Calendar;
import java.util.List;

@Slf4j
public class CicQueryJob {


    @Autowired
    CicInRepository cicInRepository;

    @Autowired
    CicOutRepository cicOutRepository;

    /**
     * 10 second
     */
    @Scheduled(fixedDelay = 10000)
    @Transactional( propagation = Propagation.REQUIRED)
    public void cicQueryRequestProcess(){
        log.trace("cic request processing ...");
        List<CicIn> cicIns = cicInRepository.findTop10ByTt(0); // ########  pending request
        for (CicIn cicIn: cicIns){
            log.info("cic request process ... #{}", cicIn);
            // mark tt = 1 and resp info
            cicIn.setTt(Integer.valueOf(1));  // ######## request completed
            cicIn.setNgayTl(Calendar.getInstance().getTime());
            cicIn = cicInRepository.save(cicIn);
            // create cic response
            CicOut cicOut = new CicOut();
            cicOut.setBankCode(cicIn.getBankCode());
            cicOut.setMaSp(cicIn.getMaSp());
            cicOut.setCicIn(cicIn); // ref
            // resp info
            cicOut.setNgayTl(Calendar.getInstance().getTime());
            cicOut.setTt(Integer.valueOf(0)); // response pending for sync
            cicOut.setNoiDung(
                    String.format(
                            "<response> " +
                                    "       <transation_id> %s </transation_id> " +
                                    "       <ms_phieu> %s </ms_phieu> " +
                                    "       <ma_cic> %s </ma_cic> " +
                                    "       <ma_sp> %s </ma_sp> " +
                                    "       <bank_code> %s </bank_code> " +
                                    "       <abc> cic info </abc> " +
                                    "</response>"
                            , cicOut.getCicIn().getId()
                            , cicOut.getId()
                            , cicOut.getCicIn().getMaCic()
                            , cicOut.getCicIn().getMaSp()
                            , cicOut.getCicIn().getBankCode()
                    ));

            cicOutRepository.save(cicOut);
            log.info("cic request process result ... #{}", cicOut);
        }

    }



}
