package vn.com.seabank.cic.sbcicnotification.web.advice;

import org.springframework.web.bind.annotation.RestControllerAdvice;
import vn.com.seabank.web.advice.ResponseEntityExceptionHandler;


@RestControllerAdvice
public class GlobalRestControllerAdvice extends ResponseEntityExceptionHandler {

}
