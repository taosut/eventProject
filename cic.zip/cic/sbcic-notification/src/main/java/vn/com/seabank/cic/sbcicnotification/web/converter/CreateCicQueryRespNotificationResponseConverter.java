package vn.com.seabank.cic.sbcicnotification.web.converter;

import vn.com.seabank.cic.sbcicnotification.service.sout.CreateCicQueryRespNotificationOut;
import vn.com.seabank.cic.sbcicnotification.web.response.CreateCicQueryRespNotificationResponse;

import java.util.function.Function;

public class CreateCicQueryRespNotificationResponseConverter implements Function<CreateCicQueryRespNotificationOut, CreateCicQueryRespNotificationResponse> {

    @Override
    public CreateCicQueryRespNotificationResponse apply(CreateCicQueryRespNotificationOut createCicQueryRespNotificationOut) {
       return CreateCicQueryRespNotificationResponse.builder()
               .id(createCicQueryRespNotificationOut.getId())
               .build();
    }
}
