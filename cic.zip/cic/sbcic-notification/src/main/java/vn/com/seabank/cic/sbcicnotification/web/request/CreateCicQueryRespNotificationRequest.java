package vn.com.seabank.cic.sbcicnotification.web.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class CreateCicQueryRespNotificationRequest {

    @JsonProperty(value = "id")
    @NotNull(message = "id is required")
    Long id;

    @JsonProperty(value = "content")
    String content;

}
