package vn.com.seabank.cic.sbcicnotification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.domain.SbReq;

import java.util.Optional;


public interface SbReqRepository extends JpaRepository<SbReq, String> {

//    Optional<SbReq> findByMaCic(String maCic);
    Optional<SbReq> findByTransactionId(long transactionId);

}
