package vn.com.seabank.cic.sbcicnotification.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import vn.com.seabank.web.filter.WebRequestTracingFilter;

@Configuration
public class WebConfig {

    @Bean
    public WebRequestTracingFilter webRequestTracingFilter(){
        return new WebRequestTracingFilter();
    }
}
