package vn.com.seabank.cic.sbcicnotification.service;


import vn.com.seabank.cic.sbcicnotification.service.sin.CreateCicQueryRespNotificationIn;
import vn.com.seabank.cic.sbcicnotification.service.sout.CreateCicQueryRespNotificationOut;

public interface SbCicService {

    CreateCicQueryRespNotificationOut createCicQueryRespNotification(CreateCicQueryRespNotificationIn createCicQueryRespNotificationIn);

}
