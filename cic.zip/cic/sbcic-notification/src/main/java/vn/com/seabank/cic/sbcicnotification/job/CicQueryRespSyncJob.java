package vn.com.seabank.cic.sbcicnotification.job;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.domain.SbResp;
import vn.com.seabank.cic.message.CicQueryRespMessage;
import vn.com.seabank.cic.sbcicnotification.repository.SbRespRepository;

import java.util.Calendar;
import java.util.List;

@Slf4j
public class CicQueryRespSyncJob {


    @Autowired
    JmsTemplate jmsTemplate;

    @Autowired
    SbRespRepository sbRespRepository;

    /**
     * transit all record has status is NOT_SYNC to SYNC_WAIT_CONFIRM
     */
    @Scheduled(fixedDelay = 1000)
    @Transactional(propagation = Propagation.REQUIRED)
    public  void cicQueryRespPublish(){

        List<SbResp> top10BySyncStatus = sbRespRepository.findTop10BySyncStatus(SbResp.SyncStatus.NOT_SYNC.name());
        for(SbResp sbResp: top10BySyncStatus){

            // update sync_status is sync_wait_confirm
            sbResp.setSyncStatus(SbResp.SyncStatus.WAIT_CONFIRM.name());
            sbResp.setSyncTime(Calendar.getInstance().getTime());

            int syncRetry = sbResp.getSyncRetry() == null ? 0 : sbResp.getSyncRetry();
            sbResp.setSyncRetry(++syncRetry);
            sbRespRepository.save(sbResp);


            // create resp message and send to queue
            CicQueryRespMessage  cicQueryRespMessage= CicQueryRespMessage.builder()
                    .traceId(sbResp.getSbReq().getTraceId())
                    .content(sbResp.getContent())
                    .build();
            jmsTemplate.convertAndSend("CIC.QUERY.RESPONSE.Q", cicQueryRespMessage);
            log.info("notification message sent to queue ... {}", cicQueryRespMessage);
        }

    }

}
