package vn.com.seabank.cic.sbcicnotification.web.converter;

import vn.com.seabank.cic.sbcicnotification.service.sin.CreateCicQueryRespNotificationIn;
import vn.com.seabank.cic.sbcicnotification.web.request.CreateCicQueryRespNotificationRequest;

import java.util.function.Function;

public class CreateCicQueryRespNotificationInConverter implements Function<CreateCicQueryRespNotificationRequest, CreateCicQueryRespNotificationIn> {


    @Override
    public CreateCicQueryRespNotificationIn apply(CreateCicQueryRespNotificationRequest createCicQueryRespNotificationRequest) {
        return CreateCicQueryRespNotificationIn.builder()
                .id(createCicQueryRespNotificationRequest.getId())
                .content(createCicQueryRespNotificationRequest.getContent())
                .build();
    }
}
