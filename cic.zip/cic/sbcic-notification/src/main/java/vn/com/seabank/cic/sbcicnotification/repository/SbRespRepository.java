package vn.com.seabank.cic.sbcicnotification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.domain.SbResp;

import java.util.List;

public interface SbRespRepository extends JpaRepository<SbResp, String> {

//    Optional<SbResp> findByMsPhieu(String msPhieu);

    List<SbResp> findTop10BySyncStatus(String syncStatus);
}
