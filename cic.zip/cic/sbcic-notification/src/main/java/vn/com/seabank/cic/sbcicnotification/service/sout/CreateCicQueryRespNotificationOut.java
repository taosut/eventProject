package vn.com.seabank.cic.sbcicnotification.service.sout;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
public class CreateCicQueryRespNotificationOut {

    long id;


}
