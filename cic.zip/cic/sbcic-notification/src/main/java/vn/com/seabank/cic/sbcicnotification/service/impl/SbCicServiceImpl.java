package vn.com.seabank.cic.sbcicnotification.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.domain.SbReq;
import vn.com.seabank.cic.domain.SbResp;
import vn.com.seabank.cic.sbcicnotification.repository.SbReqRepository;
import vn.com.seabank.cic.sbcicnotification.repository.SbRespRepository;
import vn.com.seabank.cic.sbcicnotification.service.SbCicService;
import vn.com.seabank.cic.sbcicnotification.service.converter.CreateCicQueryRespNotificationOutConverter;
import vn.com.seabank.cic.sbcicnotification.service.exception.SbReqNotFoundException;
import vn.com.seabank.cic.sbcicnotification.service.sin.CreateCicQueryRespNotificationIn;
import vn.com.seabank.cic.sbcicnotification.service.sout.CreateCicQueryRespNotificationOut;

import java.util.Calendar;
import java.util.Optional;

@Slf4j
@Service
@Transactional
public class SbCicServiceImpl implements SbCicService {

    @Autowired
    SbReqRepository sbReqRepository;

    @Autowired
    SbRespRepository sbRespRepository;

    @Override
    @Transactional(propagation =  Propagation.REQUIRED)
    public CreateCicQueryRespNotificationOut createCicQueryRespNotification(CreateCicQueryRespNotificationIn createCicQueryRespNotificationIn) {
        log.info("create query response notification ... #{}", createCicQueryRespNotificationIn);
        // make sb_reqs completed
        Optional<SbReq> sbReqOptional = sbReqRepository.findByTransactionId(createCicQueryRespNotificationIn.getId());
        if(sbReqOptional.isPresent()){
            SbReq sbReq = sbReqOptional.get();
            sbReq.setStatus(SbReq.Status.COMPLETED.name());
            sbReqRepository.save(sbReq);

            // make new sb_resp record with sync_status is not_sync
            SbResp sbResp = new SbResp();
            sbResp.setSbReq(sbReq);
            sbResp.setContent(createCicQueryRespNotificationIn.getContent());

            //
            sbResp.setSyncStatus(SbResp.SyncStatus.NOT_SYNC.name());
            sbResp = sbRespRepository.save(sbResp);

            return new CreateCicQueryRespNotificationOutConverter().apply(sbResp);
        }
        log.warn("query request is not found ... #{}", createCicQueryRespNotificationIn.getId());
        throw new SbReqNotFoundException(createCicQueryRespNotificationIn.getId());
    }


}

