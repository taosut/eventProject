package vn.com.seabank.cic.sbcicnotification.service.exception;


import vn.com.seabank.core.exception.ServiceBadException;

public class SbReqNotFoundException extends ServiceBadException {

    public SbReqNotFoundException(long transactionId) {
        super(String.format("sb_req not found ... #%s", transactionId));
    }



    @Override
    public String getErrorCode() {
        return "sb_req_not_found";
    }
}
