package vn.com.seabank.cic.sbcicnotification.web.controller;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.com.seabank.cic.sbcicnotification.service.SbCicService;
import vn.com.seabank.cic.sbcicnotification.service.sout.CreateCicQueryRespNotificationOut;
import vn.com.seabank.cic.sbcicnotification.web.converter.CreateCicQueryRespNotificationInConverter;
import vn.com.seabank.cic.sbcicnotification.web.converter.CreateCicQueryRespNotificationResponseConverter;
import vn.com.seabank.cic.sbcicnotification.web.request.CreateCicQueryRespNotificationRequest;

import javax.validation.Valid;


@Slf4j
@RestController
@RequestMapping(value = "notifications")
@Api(tags = "notifications")
public class CicNotificationController {

    @Autowired
    SbCicService sbCicService;

    @PostMapping
    public ResponseEntity<?> createCicQueryRespNotification(
            @Valid @RequestBody CreateCicQueryRespNotificationRequest createCicQueryRespNotificationRequest
    ){
        // unauthenticated
        CreateCicQueryRespNotificationOut createCicQueryRespNotificationOut = sbCicService.createCicQueryRespNotification(
                new CreateCicQueryRespNotificationInConverter().apply(createCicQueryRespNotificationRequest)
        );
        log.info("create query response notification success ... #{}", createCicQueryRespNotificationOut);
        return ResponseEntity.ok(new CreateCicQueryRespNotificationResponseConverter().apply(createCicQueryRespNotificationOut));
    }


}
