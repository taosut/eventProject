package vn.com.seabank.cic.sbcicnotification.service.converter;

import vn.com.seabank.cic.domain.SbResp;
import vn.com.seabank.cic.sbcicnotification.service.sout.CreateCicQueryRespNotificationOut;

import java.util.function.Function;


public class CreateCicQueryRespNotificationOutConverter implements Function<SbResp, CreateCicQueryRespNotificationOut> {


    @Override
    public CreateCicQueryRespNotificationOut apply(SbResp sbResp) {
       return CreateCicQueryRespNotificationOut.builder()
               .id(sbResp.getId())
               .build();
    }
}
