package vn.com.seabank.cic.sbcicgate.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import vn.com.seabank.cic.sbcicgate.config.FeignConfig;
import vn.com.seabank.cic.sbcicgate.feign.request.CicQueryRequest;
import vn.com.seabank.cic.sbcicgate.feign.response.CicQueryResponse;

@FeignClient(
        name = "cicQueryClient",
        url = "http://localhost:9000/query",
        configuration = FeignConfig.class)
public interface CicQueryClient {

    @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
    CicQueryResponse createCicQueryRequest(CicQueryRequest cicQueryRequest);
}
