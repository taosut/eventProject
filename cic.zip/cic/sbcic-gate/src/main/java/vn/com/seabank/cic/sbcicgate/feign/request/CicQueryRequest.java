package vn.com.seabank.cic.sbcicgate.feign.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@ToString
@Builder
public class CicQueryRequest {

    @JsonProperty(value = "trace_id")
    String traceId;

    @JsonProperty(value = "product_code")
    String productCode;

    @JsonProperty(value = "content")
    String content;

}
