package vn.com.seabank.cic.sbcicgate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.domain.SbReq;

import java.util.Optional;


public interface SbReqRepository extends JpaRepository<SbReq, Long> {

    Optional<SbReq> findByTraceId(String traceId);

}
