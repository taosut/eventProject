package vn.com.seabank.cic.sbcicgate.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.domain.SbReq;
import vn.com.seabank.cic.domain.SbResp;
import vn.com.seabank.cic.message.CicConfirmMessage;
import vn.com.seabank.cic.message.CicQueryMessage;
import vn.com.seabank.cic.sbcicgate.feign.CicQueryClient;
import vn.com.seabank.cic.sbcicgate.repository.SbReqRepository;
import vn.com.seabank.cic.sbcicgate.repository.SbRespRepository;
import vn.com.seabank.cic.sbcicgate.feign.request.CicQueryRequest;
import vn.com.seabank.cic.sbcicgate.feign.response.CicQueryResponse;

import java.util.Optional;

@Slf4j
public class CicQueryMessageConsumer {


    @Autowired
    SbReqRepository sbReqRepository;

    @Autowired
    CicQueryClient cicQueryClient;

    @JmsListener(destination = "CIC.QUERY.REQUEST.Q", containerFactory = "myFactory")
    @Transactional(propagation = Propagation.REQUIRED)
    public void cicQueryRequest(CicQueryMessage cicQueryMessage) {
        log.info("query request message process ... #{}" , cicQueryMessage);
        // validate by trace_id

        Optional<SbReq> sbReqOptional = sbReqRepository.findByTraceId(cicQueryMessage.getTraceId());
        if(!sbReqOptional.isPresent()){
            // insert new sb_req log, status = CREATED
            SbReq sbReq = new SbReq();
            sbReq.setTraceId(cicQueryMessage.getTraceId());
            sbReq.setProductCode(cicQueryMessage.getProductCode());
            sbReq.setContent(cicQueryMessage.getContent()); // write as json object
            sbReq.setStatus(SbReq.Status.CREATED.name());
            sbReqRepository.save(sbReq);

            // call cic-gate rest request -->
            // prepare parameters
            CicQueryRequest cicQueryRequest = CicQueryRequest.builder()
                    .traceId(cicQueryMessage.getTraceId())
                    .productCode(cicQueryMessage.getProductCode())
                    .content(cicQueryMessage.getContent())
                    .build();
            // http sending
            CicQueryResponse cicQueryResponse = cicQueryClient.createCicQueryRequest(cicQueryRequest);
            log.info("query request result ... #{}" , cicQueryResponse);

            // update request with transaction_id
            sbReq.setTransactionId(cicQueryResponse.getId());
            sbReq.setStatus(SbReq.Status.WAITING.name());
            sbReqRepository.save(sbReq);
            log.info("query request processed ... #{}" , sbReq);
            return;
        }
        log.error("query request duplicated ... #{}" , cicQueryMessage.getTraceId());
    }

}
