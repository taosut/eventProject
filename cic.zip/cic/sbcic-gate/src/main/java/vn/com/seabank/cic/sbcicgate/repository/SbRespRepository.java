package vn.com.seabank.cic.sbcicgate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.domain.SbResp;

import java.util.List;

public interface SbRespRepository extends JpaRepository<SbResp, Long> {

//    Optional<SbResp> findByMsPhieu(String msPhieu);

    List<SbResp> findBySbReqId(long sbReqId);

//    List<SbResp> findTop10BySyncStatus(String syncStatus);

}
