package vn.com.seabank.cic.sbcicgate.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.domain.SbReq;
import vn.com.seabank.cic.domain.SbResp;
import vn.com.seabank.cic.message.CicConfirmMessage;
import vn.com.seabank.cic.message.CicQueryMessage;
import vn.com.seabank.cic.sbcicgate.feign.CicQueryClient;
import vn.com.seabank.cic.sbcicgate.feign.request.CicQueryRequest;
import vn.com.seabank.cic.sbcicgate.feign.response.CicQueryResponse;
import vn.com.seabank.cic.sbcicgate.repository.SbReqRepository;
import vn.com.seabank.cic.sbcicgate.repository.SbRespRepository;

import java.util.List;
import java.util.Optional;

@Slf4j
public class CicConfirmMessageConsumer {


    @Autowired
    SbReqRepository sbReqRepository;

    @Autowired
    SbRespRepository sbRespRepository;


    @JmsListener(destination = "CIC.QUERY.CONFIRM.Q", containerFactory = "myFactory")
    @Transactional(propagation = Propagation.REQUIRED)
    public void cicConfirmRequest(CicConfirmMessage cicConfirmMessage) {
        log.info("confirm request message process ... #{}" , cicConfirmMessage);
        // validate request by trace_id
        Optional<SbReq> sbReqOptional = sbReqRepository.findByTraceId(cicConfirmMessage.getTraceId());
        if(sbReqOptional.isPresent()){
            // find and update sb_resp, status = SYNCED
            List<SbResp> sbRespList = sbRespRepository.findBySbReqId(sbReqOptional.get().getId());

            for(SbResp sbResp : sbRespList){
                //
                if(!SbResp.SyncStatus.SYNCED.name()
                        .equalsIgnoreCase(sbResp.getSyncStatus())){
                    log.info("transit status from #{} to #{}", sbResp.getSyncStatus(), SbResp.SyncStatus.SYNCED.name());
                    sbResp.setSyncStatus(SbResp.SyncStatus.SYNCED.name());
                    sbRespRepository.save(sbResp);

                }
            }
            return;
        }
        log.error("confirm request is not found ... #{}" , cicConfirmMessage.getTraceId());
    }
}
