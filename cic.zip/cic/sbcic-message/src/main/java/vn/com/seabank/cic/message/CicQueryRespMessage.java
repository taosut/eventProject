package vn.com.seabank.cic.message;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

@Value
@Builder
public class CicQueryRespMessage{


    @JsonProperty(value = "trace_id")
    String traceId;

 /*   @JsonProperty(value = "product_code")
    String productCode;

    @JsonProperty(value = "ma_cic")
    String maCic;

    @JsonProperty(value = "cmnd")
    String cmnd;*/

    @JsonProperty(value = "content")
    String content;

}
