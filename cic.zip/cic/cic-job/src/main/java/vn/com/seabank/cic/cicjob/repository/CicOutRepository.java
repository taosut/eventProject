package vn.com.seabank.cic.cicjob.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.domain.CicOut;

import java.util.List;


public interface CicOutRepository extends JpaRepository<CicOut, String> {

    List<CicOut> findTop10ByTt(int tt);
}
