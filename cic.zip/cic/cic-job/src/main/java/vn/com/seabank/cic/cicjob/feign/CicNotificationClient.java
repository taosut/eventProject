package vn.com.seabank.cic.cicjob.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import vn.com.seabank.cic.cicjob.config.FeignConfig;
import vn.com.seabank.cic.cicjob.feign.request.CreateCicQueryRespNotificationRequest;
import vn.com.seabank.cic.cicjob.feign.response.CreateCicQueryRespNotificationResponse;

@FeignClient(
        name = "cicNotificationClient",
        url = "http://localhost:8100/notifications",
        configuration = FeignConfig.class)
public interface CicNotificationClient {

    @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
    CreateCicQueryRespNotificationResponse createCicQueryRespNotification(CreateCicQueryRespNotificationRequest createCicQueryRespNotificationRequest);
}
