package vn.com.seabank.cic.cicjob.feign.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;


@Value
@Builder
public class CreateCicQueryRespNotificationRequest {

    @JsonProperty(value = "id")
    long id;

    @JsonProperty(value = "content")
    String content;


}
