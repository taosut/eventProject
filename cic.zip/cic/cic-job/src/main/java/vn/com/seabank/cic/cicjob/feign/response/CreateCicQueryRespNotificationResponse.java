package vn.com.seabank.cic.cicjob.feign.response;

import lombok.*;

@Value
@Builder
public class CreateCicQueryRespNotificationResponse {

    long id;

}
