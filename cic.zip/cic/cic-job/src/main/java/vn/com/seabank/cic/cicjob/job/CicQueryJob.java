package vn.com.seabank.cic.cicjob.job;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.cicjob.feign.CicNotificationClient;
import vn.com.seabank.cic.cicjob.repository.CicOutRepository;
import vn.com.seabank.cic.cicjob.feign.request.CreateCicQueryRespNotificationRequest;
import vn.com.seabank.cic.cicjob.feign.response.CreateCicQueryRespNotificationResponse;
import vn.com.seabank.cic.domain.CicOut;

import java.util.List;

@Slf4j
public class CicQueryJob {


    @Autowired
    CicOutRepository cicOutRepository;

    @Autowired
    CicNotificationClient cicNotificationClient;

    @Scheduled(fixedDelay = 1000)
    @Transactional( propagation = Propagation.REQUIRED)
    public void cicQueryRespProcess(){

        log.trace("cic processing ...");
        List<CicOut> cicOuts = cicOutRepository.findTop10ByTt(0); // ########  pending sync
        for (CicOut cicOut: cicOuts){
            log.info("cic response process ... #{}", cicOut.getId());

            //####  make notification
            // param
            CreateCicQueryRespNotificationRequest cicQueryRespNotificationRequest
                    = CreateCicQueryRespNotificationRequest.builder()
                    .id(cicOut.getCicIn().getId())
                    .content(cicOut.getNoiDung())
                    .build();

            // http sending
            CreateCicQueryRespNotificationResponse cicQueryRespNotification = cicNotificationClient.createCicQueryRespNotification(cicQueryRespNotificationRequest);

            //
            cicOut.setTt(Integer.valueOf(1));  // ######## synced
            cicOutRepository.save(cicOut);
            log.info("cic response synced ... #{}" , cicOut.getId());
        }
    }

}
