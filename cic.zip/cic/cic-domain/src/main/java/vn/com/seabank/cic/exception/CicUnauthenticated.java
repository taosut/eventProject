package vn.com.seabank.cic.exception;


import lombok.Getter;
import lombok.Setter;
import vn.com.seabank.core.exception.ServiceBadException;

@Setter
@Getter
public class CicUnauthenticated extends ServiceBadException {


    public CicUnauthenticated(String message) {
        super(message);
    }

    @Override
    public String getErrorCode() {
        return "cic_authenticated_failure";
    }
}
