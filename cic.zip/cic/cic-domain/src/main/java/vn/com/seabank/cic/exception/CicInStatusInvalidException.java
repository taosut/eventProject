package vn.com.seabank.cic.exception;


import vn.com.seabank.core.exception.ServiceBadException;

public class CicInStatusInvalidException  extends ServiceBadException {

    public CicInStatusInvalidException(String status) {
        super(String.format("status is invalid. %s", status));
    }

    @Override
    public String getErrorCode() {
        return "cic_in_status_invalid";
    }
}
