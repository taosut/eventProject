package vn.com.seabank.cic.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import vn.com.seabank.cic.exception.CicOutStatusInvalidException;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "tbl_cic_out")
public class CicOut {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    Long id;

    @Column(name = "ms_phieu")
    String msPhieu;

    @Column(name = "ngay_tl")
    @Temporal(value = TemporalType.TIMESTAMP)
    @CreatedDate
    Date ngayTl;

    @Column(name = "noi_dung")
    String noiDung;

    @Column(name = "tt")
    Integer tt;

    @Column(name = "ma_sp")
    String maSp;

    @Column(name = "ngay_sl")
    String ngaySl;

    @Column(name = "bank_code")
    String bankCode;

    @ManyToOne(optional = false, fetch=FetchType.LAZY)
    @JoinColumn(name = "tbl_cic_in_id", referencedColumnName = "id")
    CicIn cicIn;

    @PrePersist
    public void prePersist () {
        this.ngayTl = this.ngayTl == null ? Calendar.getInstance().getTime() : this.ngayTl;
    }


    public enum Status {
        PENDING, FINISHED;

        static public CicIn.Status find(String value) {
            for (CicIn.Status item : CicIn.Status.values()) {
                if ( item.name().equalsIgnoreCase(value) ) return item;
            }
            throw new CicOutStatusInvalidException(value);
        }
    }

    @Override
    public String toString() {
        return "CicOut{" +
                "id='" + id + '\'' +
                ", msPhieu='" + msPhieu + '\'' +
                ", ngayTl=" + ngayTl +
                ", noiDung='" + noiDung + '\'' +
                ", tt=" + tt +
                ", maSp='" + maSp + '\'' +
                ", ngaySl='" + ngaySl + '\'' +
                ", bankCode='" + bankCode + '\'' +
                '}';
    }
}
