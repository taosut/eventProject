package vn.com.seabank.cic.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import vn.com.seabank.cic.exception.CicInStatusInvalidException;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "tbl_cic_in")
public class CicIn {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    Long id;

    @Column(name = "dia_chi")
    String diaChi;

    @Column(name = "dkkd")
    String dkkd;

    @Column(name = "ghi_chu")
    String ghiChu;

    @Column(name = "loai")
    String loai;

    @Column(name = "loai_gtk")
    String loaiGtk;

    @Column(name = "loai_kh")
    String loaiKh;

    @Column(name = "ma_cic")
    String maCic;

    @Column(name = "ma_sp")
    String maSp;

    @Column(name = "ma_tctd")
    String maTctd;

    @Column(name = "ms_thue")
    String msThue;

    @Column(name = "ngay_hoi")
    @Temporal(value = TemporalType.TIMESTAMP)
    @CreatedDate
    Date ngayHoi;

    @Column(name = "so_gtk")
    String soGtk;

    @Column(name = "so_cmt")
    String soCmt;

    @Column(name = "ten_kh")
    String tenKh;

    @Column(name = "tt")
    Integer tt;

    @Column(name = "user_name")
    String username;

    @Column(name = "ngay_tl")
    @Temporal(value = TemporalType.TIMESTAMP)
    Date ngayTl;

    @Column(name = "ngay_sl")
    String ngaySl;

    @Column(name = "bank_code")
    String bankCode;

    @Column(name = "ngay_tao")
    @Temporal(value = TemporalType.TIMESTAMP)
    @CreatedDate
    Date ngayTao;

    @Column(name = "loai_cic5")
    String loaiCic5;

    @Column(name = "da_gui")
    Integer daGui;

    @OneToMany(mappedBy="cicIn",fetch = FetchType.LAZY)
    List<CicOut> cicOuts;

    @PrePersist
    public void prePersist () {
        this.ngayHoi = this.ngayHoi == null ? Calendar.getInstance().getTime() : this.ngayHoi;
        this.ngayTao = this.ngayTao == null ? Calendar.getInstance().getTime() : this.ngayTao;
    }

    public enum Status {
        PENDING, FINISHED;

        static public Status find(String value) {
            for (Status item : Status.values()) {
                if ( item.name().equalsIgnoreCase(value) ) return item;
            }
            throw new CicInStatusInvalidException(value);
        }
    }


    @Override
    public String toString() {
        return "CicIn{" +
                "id='" + id + '\'' +
                ", diaChi='" + diaChi + '\'' +
                ", dkkd='" + dkkd + '\'' +
                ", ghiChu='" + ghiChu + '\'' +
                ", loai='" + loai + '\'' +
                ", loaiGtk=" + loaiGtk +
                ", loaiKh=" + loaiKh +
                ", maCic='" + maCic + '\'' +
                ", maSp='" + maSp + '\'' +
                ", maTctd=" + maTctd +
                ", msThue='" + msThue + '\'' +
                ", ngayHoi=" + ngayHoi +
                ", soGtk='" + soGtk + '\'' +
                ", soCmt='" + soCmt + '\'' +
                ", tenKh='" + tenKh + '\'' +
                ", tt=" + tt +
                ", username='" + username + '\'' +
                ", ngayTl=" + ngayTl +
                ", ngaySl='" + ngaySl + '\'' +
                ", bankCode='" + bankCode + '\'' +
                ", ngayTao=" + ngayTao +
                ", loaiCic5='" + loaiCic5 + '\'' +
                ", daGui=" + daGui +
                '}';
    }
}
