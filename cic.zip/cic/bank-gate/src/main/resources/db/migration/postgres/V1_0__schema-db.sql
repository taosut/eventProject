CREATE TABLE bank_reqs (
  id           BIGSERIAL NOT NULL,
  trace_id     varchar(255) UNIQUE,
  product_code varchar(255) NOT NULL,
  content_     text NOT NULL,
  content_hash varchar(255),
  created_time timestamp NOT NULL,
  status       varchar(50) NOT NULL,
  PRIMARY KEY (id));
COMMENT ON COLUMN bank_reqs.trace_id IS 'trace ID từ bank gửi sang CIC Gateway';
COMMENT ON COLUMN bank_reqs.product_code IS 'Mã gói sản phẩn truy vấn';
COMMENT ON COLUMN bank_reqs.content_ IS 'Nội dung Request (Message content khi MQ, Request Body khi HTTP)';
COMMENT ON COLUMN bank_reqs.status IS 'CREATED|WAITING|COMPLETE|ERROR trạng thái của Request';
CREATE TABLE bank_resps (
  id           BIGSERIAL NOT NULL,
  bank_reqs_id int8 NOT NULL,
  content_     text,
  content_hash varchar(255),
  created_time timestamp NOT NULL,
  PRIMARY KEY (id));
COMMENT ON COLUMN bank_resps.content_ IS 'Nội dung bản tin CIC trả lời, dạng text';
ALTER TABLE bank_resps ADD CONSTRAINT FKbank_resps21849 FOREIGN KEY (bank_reqs_id) REFERENCES bank_reqs (id);
