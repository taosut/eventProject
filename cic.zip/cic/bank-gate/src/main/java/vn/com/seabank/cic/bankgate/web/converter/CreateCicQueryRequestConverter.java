package vn.com.seabank.cic.bankgate.web.converter;

import vn.com.seabank.cic.bankgate.service.sin.CreateCicQueryIn;
import vn.com.seabank.cic.bankgate.web.request.CreateCicQueryRequest;

import java.util.function.Function;

public class CreateCicQueryRequestConverter implements Function<CreateCicQueryRequest, CreateCicQueryIn> {

    @Override
    public CreateCicQueryIn apply(CreateCicQueryRequest createCicQueryRequest) {

      return CreateCicQueryIn.builder()
              .productCode(createCicQueryRequest.getProductCode())
              .content(createCicQueryRequest.getContent())
              .build();

    }
}
