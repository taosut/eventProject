package vn.com.seabank.cic.bankgate.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.bankgate.domain.BankResp;

public interface BankRespRepository extends JpaRepository<BankResp, Long> {

}
