package vn.com.seabank.cic.bankgate.service.sin;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@Builder
@ToString
public class CreateCicQueryIn {

    String traceId;
    String productCode;
    String content;



}



