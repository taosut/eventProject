package vn.com.seabank.cic.bankgate.web.controller;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import vn.com.seabank.cic.bankgate.service.BankCicService;
import vn.com.seabank.cic.bankgate.service.sin.CreateCicQueryIn;
import vn.com.seabank.cic.bankgate.service.sout.CreateCicQueryOut;
import vn.com.seabank.cic.bankgate.web.converter.CreateCicQueryRequestConverter;
import vn.com.seabank.cic.bankgate.web.converter.CreateCicQueryResponseConverter;
import vn.com.seabank.cic.bankgate.web.request.CreateCicQueryRequest;

import javax.validation.Valid;
import java.util.UUID;


@Slf4j
@RestController
@Api(tags = "Bank Cic")
public class BankCicController {


    @Autowired
    BankCicService bankCicService;


    @PostMapping(value = "query")
    public ResponseEntity<?> createCicQueryRequest(
            @Valid @RequestBody CreateCicQueryRequest createCicQueryRequest
    ){
        // make request
        CreateCicQueryIn createCicQueryIn = new CreateCicQueryRequestConverter().apply(createCicQueryRequest);
        // enrich
        createCicQueryIn.setTraceId(UUID.randomUUID().toString());

        CreateCicQueryOut createCicQueryOut = bankCicService.createCicQuery(createCicQueryIn);
        log.info("create cic query success ... #{}", createCicQueryOut);
        return ResponseEntity.ok(
                new CreateCicQueryResponseConverter().apply(createCicQueryOut)
        );
    }


}
