package vn.com.seabank.cic.bankgate.service.exception;

import vn.com.seabank.core.exception.ServiceBadException;

public class BankReqStatusInvalidException extends ServiceBadException {

    public BankReqStatusInvalidException(String status) {
        super(String.format("status is invalid. %s", status));
    }

    @Override
    public String getErrorCode() {
        return "bank_req_status_invalid";
    }
}
