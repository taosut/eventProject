package vn.com.seabank.cic.bankgate.service;


import vn.com.seabank.cic.bankgate.service.sin.CreateCicQueryIn;
import vn.com.seabank.cic.bankgate.service.sout.CreateCicQueryOut;

public interface BankCicService {

    CreateCicQueryOut createCicQuery(CreateCicQueryIn createCicQueryIn);

}
