package vn.com.seabank.cic.bankgate.web.converter;

import vn.com.seabank.cic.bankgate.service.sout.CreateCicQueryOut;
import vn.com.seabank.cic.bankgate.web.response.CreateCicQueryResponse;

import java.util.function.Function;

public class CreateCicQueryResponseConverter implements Function<CreateCicQueryOut, CreateCicQueryResponse> {

    @Override
    public CreateCicQueryResponse apply(CreateCicQueryOut createCicQueryOut) {

      return CreateCicQueryResponse.builder()
              .traceId(createCicQueryOut.getTraceId())
              .status(createCicQueryOut.getStatus())
              .build();

    }
}
