package vn.com.seabank.cic.bankgate.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import vn.com.seabank.cic.bankgate.job.CicQueryJob;

@Configuration
@EnableScheduling
public class JobConfig {


    @Bean
    public CicQueryJob cicQueryJob(){
        return new CicQueryJob();
    }

}
