package vn.com.seabank.cic.bankgate.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.bankgate.domain.BankReq;
import vn.com.seabank.cic.bankgate.domain.BankResp;
import vn.com.seabank.cic.bankgate.repository.BankReqRepository;
import vn.com.seabank.cic.bankgate.repository.BankRespRepository;
import vn.com.seabank.cic.message.CicConfirmMessage;
import vn.com.seabank.cic.message.CicQueryRespMessage;

import java.util.Optional;

@Slf4j
public class CicQueryRespMessageConsumer {


    @Autowired
    BankReqRepository bankReqRepository;

    @Autowired
    BankRespRepository bankRespRepository;

    @Autowired
    JmsTemplate jmsTemplate;


    @JmsListener(destination = "CIC.QUERY.RESPONSE.Q", containerFactory = "myFactory")
    @Transactional(propagation = Propagation.REQUIRED)
    public void cicQueryRequest(CicQueryRespMessage cicQueryRespMessage) {
        log.info("response message process ... #{}" , cicQueryRespMessage);
        // validate request by trace_id
        Optional<BankReq> sbReqOptional = bankReqRepository.findByTraceId(cicQueryRespMessage.getTraceId());
        if(sbReqOptional.isPresent()){
            // update request record
            BankReq bankReq = sbReqOptional.get();
            bankReq.setStatus(BankReq.Status.COMPLETED.name());
            bankReqRepository.save(bankReq);
            log.info("query request completed ... #{}", bankReq);

            // insert new resp record - now, not check duplicate
            BankResp bankResp = new BankResp();
            bankResp.setBankReq(bankReq);
            bankResp.setContent(cicQueryRespMessage.getContent());
            bankRespRepository.save(bankResp);
            log.info("query response saved ... #{}", bankResp);

            // send confirm message to queue
            CicConfirmMessage cicConfirmMessage = CicConfirmMessage.builder()
                    .traceId(cicQueryRespMessage.getTraceId())
                    .build();
            jmsTemplate.convertAndSend("CIC.QUERY.CONFIRM.Q", cicConfirmMessage);
            log.info("confirm message sent into CIC.QUERY.CONFIRM.Q  ... #{}", cicConfirmMessage);
        }
        log.warn("query request not found ... #{}", cicQueryRespMessage.getTraceId());
    }


}
