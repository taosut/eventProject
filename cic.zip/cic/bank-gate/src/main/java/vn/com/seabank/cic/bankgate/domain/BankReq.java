package vn.com.seabank.cic.bankgate.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.util.DigestUtils;
import vn.com.seabank.cic.bankgate.service.exception.BankReqStatusInvalidException;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "bank_reqs")
@EntityListeners(AuditingEntityListener.class)
public class BankReq {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    Long id;

    @Column(name = "trace_id", unique = true)
    String traceId;

    @Column(name = "product_code")
    String productCode;

    @Column(name = "content_")
    String content;

    @Column(name = "content_hash")
    String contentHash;

    @Column(name = "created_time")
    @Temporal(value = TemporalType.TIMESTAMP)
    @CreatedDate
    Date createdTime;

    @Column(name = "status")
    String status;

    @OneToMany(mappedBy="bankReq",fetch = FetchType.LAZY)
    List<BankResp> bankResps;

    @PrePersist
    public void prePersist(){
        this.contentHash = this.content == null ? null : DigestUtils.md5DigestAsHex(this.content.getBytes());
    }

    @Override
    public String toString() {
        return "BankReq{" +
                "id=" + id +
                ", traceId='" + traceId + '\'' +
                ", productCode='" + productCode + '\'' +
                ", content='" + content + '\'' +
                ", contentHash='" + contentHash + '\'' +
                ", createdTime=" + createdTime +
                ", status='" + status + '\'' +
                '}';
    }

    public enum Status {
        CREATED, WAITING, COMPLETED, ERROR;

        static public Status find(String value) {
            for (Status item : Status.values()) {
                if ( item.name().equalsIgnoreCase(value) ) return item;
            }
            throw new BankReqStatusInvalidException(value);
        }
    }

}
