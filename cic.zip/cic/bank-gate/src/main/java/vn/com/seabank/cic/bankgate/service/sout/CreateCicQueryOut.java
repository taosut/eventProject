package vn.com.seabank.cic.bankgate.service.sout;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@Builder
@ToString
public class CreateCicQueryOut {

    String traceId;
    String status;

}
