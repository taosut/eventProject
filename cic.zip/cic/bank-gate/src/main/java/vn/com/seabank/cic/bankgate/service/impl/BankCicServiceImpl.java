package vn.com.seabank.cic.bankgate.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;
import vn.com.seabank.cic.bankgate.domain.BankReq;
import vn.com.seabank.cic.bankgate.repository.BankReqRepository;
import vn.com.seabank.cic.bankgate.service.BankCicService;
import vn.com.seabank.cic.bankgate.service.converter.CreateCicQueryOutConverter;
import vn.com.seabank.cic.bankgate.service.sin.CreateCicQueryIn;
import vn.com.seabank.cic.bankgate.service.sout.CreateCicQueryOut;

import java.util.Optional;

@Slf4j
@Service
@Transactional
public class BankCicServiceImpl implements BankCicService {

    @Autowired
    BankReqRepository bankReqRepository;

    @Override
    @Transactional(propagation =  Propagation.REQUIRED)
    public CreateCicQueryOut createCicQuery(CreateCicQueryIn createCicQueryIn) {
        log.info("create query request ... #{}", createCicQueryIn);
        // validate
        String hash = DigestUtils.md5DigestAsHex(createCicQueryIn.getContent().getBytes());
        Optional<BankReq> sbReqOptional =
                bankReqRepository.findFirstByProductCodeAndContentHash(createCicQueryIn.getProductCode(), hash);

        if(sbReqOptional.isPresent()){
            log.info("query request has already been processed ... #{}", sbReqOptional.get());
            return new CreateCicQueryOutConverter().apply(sbReqOptional.get());
        }
        // create new
        BankReq bankReq = new BankReq();
        bankReq.setTraceId(createCicQueryIn.getTraceId());
        bankReq.setProductCode(createCicQueryIn.getProductCode());
        bankReq.setContent(createCicQueryIn.getContent());
        bankReq.setStatus(BankReq.Status.CREATED.name());

        bankReqRepository.save(bankReq);
        return new CreateCicQueryOutConverter().apply(bankReq);
    }
}

