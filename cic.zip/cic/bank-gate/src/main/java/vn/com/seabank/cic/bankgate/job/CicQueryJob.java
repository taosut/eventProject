package vn.com.seabank.cic.bankgate.job;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import vn.com.seabank.cic.bankgate.domain.BankReq;
import vn.com.seabank.cic.bankgate.repository.BankReqRepository;
import vn.com.seabank.cic.message.CicQueryMessage;

import java.util.List;

@Slf4j
public class CicQueryJob {


    @Autowired
    JmsTemplate jmsTemplate;

    @Autowired
    BankReqRepository bankReqRepository;


    /**
     * send query request into queue and
     * transit all record has status is CREATED to WAITING
     */
    @Scheduled(fixedDelay = 1000)
    @Transactional(propagation = Propagation.REQUIRED)
    public  void cicQueryRespPublish(){
        log.trace("cic query process ..." );

        List<BankReq> bankReqs = bankReqRepository.findTop10ByStatus(BankReq.Status.CREATED.name());
        for(BankReq bankReq : bankReqs){
            // status to WAITING
            bankReq.setStatus(BankReq.Status.WAITING.name());
            bankReqRepository.save(bankReq);
            log.info("query request transit into WAITING ... #{}", bankReq.getId());

            // create messgage
            CicQueryMessage cicQueryMessage = CicQueryMessage.builder()
                    .traceId(bankReq.getTraceId())
                    .productCode(bankReq.getProductCode())
                    .content(bankReq.getContent())
                    .build();

            // send query message to queue
            jmsTemplate.convertAndSend("CIC.QUERY.REQUEST.Q", cicQueryMessage);
            log.info("query message sent into CIC.QUERY.REQUEST.Q  ... #{}", cicQueryMessage);

        }

    }

}
