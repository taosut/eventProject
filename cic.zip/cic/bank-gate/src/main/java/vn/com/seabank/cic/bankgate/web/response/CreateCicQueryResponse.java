package vn.com.seabank.cic.bankgate.web.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
public class CreateCicQueryResponse {

    @JsonProperty( value = "trace_id")
    String traceId;

    @JsonProperty( value = "status")
    String status;


}
