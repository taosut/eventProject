package vn.com.seabank.cic.bankgate.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.util.DigestUtils;

import javax.persistence.*;
import java.util.Date;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "bank_resps")
@EntityListeners(AuditingEntityListener.class)
public class BankResp {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    Long id;

    @Column(name = "content_")
    String content;

    @Column(name = "content_hash")
    String contentHash;

    @Column(name = "created_time")
    @Temporal(value = TemporalType.TIMESTAMP)
    @CreatedDate
    Date createdTime;

    @ManyToOne(optional = false, fetch=FetchType.LAZY)
    @JoinColumn(name = "bank_reqs_id", referencedColumnName = "id")
    BankReq bankReq;


    @PrePersist
    public void prePersist(){
        this.contentHash = this.content == null ? null : DigestUtils.md5DigestAsHex(this.content.getBytes());
    }

    @Override
    public String toString() {
        return "BankResp{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", contentHash='" + contentHash + '\'' +
                ", createdTime=" + createdTime +
                '}';
    }


}
