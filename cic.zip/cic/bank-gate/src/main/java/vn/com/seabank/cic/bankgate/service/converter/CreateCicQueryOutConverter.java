package vn.com.seabank.cic.bankgate.service.converter;


import vn.com.seabank.cic.bankgate.domain.BankReq;
import vn.com.seabank.cic.bankgate.service.sout.CreateCicQueryOut;

import java.util.function.Function;


public class CreateCicQueryOutConverter implements Function<BankReq, CreateCicQueryOut> {


    @Override
    public CreateCicQueryOut apply(BankReq bankReq) {

       return CreateCicQueryOut.builder()
                .traceId(bankReq.getTraceId())
                .status(bankReq.getStatus())
                .build();
    }
}
