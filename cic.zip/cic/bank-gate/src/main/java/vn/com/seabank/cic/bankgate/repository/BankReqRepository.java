package vn.com.seabank.cic.bankgate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.seabank.cic.bankgate.domain.BankReq;

import java.util.List;
import java.util.Optional;

public interface BankReqRepository extends JpaRepository<BankReq, Long> {

    List<BankReq> findTop10ByStatus(String status);
    Optional<BankReq> findByTraceId(String traceId);
    Optional<BankReq> findFirstByProductCodeAndContentHash(String productCode, String contentHash);
}
