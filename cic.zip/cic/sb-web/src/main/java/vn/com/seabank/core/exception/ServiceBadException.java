package vn.com.seabank.core.exception;

/**
 * Bad request exception
 */
public abstract class ServiceBadException extends ServiceException {

    public ServiceBadException(String message) {
        super(message);
    }

    public ServiceBadException(String message, Throwable cause) {
        super(message, cause);
    }

    @Override
    public int getHttpErrorCode() {
        // The spec says this is a bad request
        return 400;
    }

    @Override
    public abstract String getErrorCode();


}
