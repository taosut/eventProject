package vn.com.seabank.core.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.List;


public class ErrorResponseEntity implements Serializable {

    @JsonProperty(value = "error")
    String error;

    @JsonProperty(value = "error_description")
    String errorDescription;


    @JsonProperty(value = "error_fields")
    List<ErrorFieldResponseEntity> errorFields;


    public ErrorResponseEntity(String error, String errorDescription, List<ErrorFieldResponseEntity> errorFields) {
        this.error = error;
        this.errorDescription = errorDescription;
        this.errorFields = errorFields;
    }

    public static ErrorResponseEntity.ErrorResponseEntityBuilder builder() {
        return new ErrorResponseEntity.ErrorResponseEntityBuilder();
    }


    public String getError() {
        return error;
    }


    public String getErrorDescription() {
        return errorDescription;
    }


    public List<ErrorFieldResponseEntity> getErrorFields() {
        return errorFields;
    }

    @Override
    public String toString() {
        return "ErrorResponseEntity{" +
                "error='" + error + '\'' +
                ", errorDescription='" + errorDescription + '\'' +
                ", errorFields=" + errorFields +
                '}';
    }

    public static class ErrorResponseEntityBuilder {

        private String error;

        private String errorDescription;

        private List<ErrorFieldResponseEntity> errorFields;

        ErrorResponseEntityBuilder() {
        }

        public ErrorResponseEntity.ErrorResponseEntityBuilder error(final String error) {
            this.error = error;
            return this;
        }

        public ErrorResponseEntity.ErrorResponseEntityBuilder errorDescription(final String errorDescription) {
            this.errorDescription = errorDescription;
            return this;
        }

        public ErrorResponseEntity.ErrorResponseEntityBuilder errorFields(final List<ErrorFieldResponseEntity> errorFields) {
            this.errorFields = errorFields;
            return this;
        }


        public ErrorResponseEntity build() {
            return new ErrorResponseEntity(this.error, this.errorDescription, this.errorFields);
        }

        @Override
        public String toString() {
            return "ErrorResponseEntityBuilder{" +
                    "error='" + error + '\'' +
                    ", errorDescription='" + errorDescription + '\'' +
                    ", errorFields=" + errorFields +
                    '}';
        }
    }
}