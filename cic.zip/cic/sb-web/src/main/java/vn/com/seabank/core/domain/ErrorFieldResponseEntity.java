package vn.com.seabank.core.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;


/**
 *
     {
     “name” : “league_id”,
//     "type" : "String"
     “value”: “1_abc”,
     “message”: “League ID không hợp lệ”
     }
 */
public class ErrorFieldResponseEntity implements Serializable{

    @JsonProperty(value = "name")
    String name;

    @JsonProperty(value = "value")
    String value;

    @JsonProperty(value = "message")
    String message;

    public ErrorFieldResponseEntity() {
    }

    public ErrorFieldResponseEntity(String name, String value, String message) {
        this.name = name;
        this.value = value;
        this.message = message;
    }

    public String getName() {
        return name;
    }


    public String getValue() {
        return value;
    }


    public String getMessage() {
        return message;
    }


    @Override
    public String toString() {
        return "ErrorFieldResponseEntity{" +
                "name='" + name + '\'' +
                ", value='" + value + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
