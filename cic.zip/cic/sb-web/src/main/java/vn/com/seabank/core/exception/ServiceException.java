package vn.com.seabank.core.exception;

/**
 * Service base exception
 *
 * eg
 * http status 500
 * {
 *     error: "server_internal_error",
 *     error_description: "exception message"
 * }
 */

public class ServiceException extends RuntimeException{

    public static final String DEFAULT_ERROR_CODE = "service_exception";
    public static final int DEFAULT_HTTP_ERROR_CODE = 500;


    public ServiceException(String message) {
        super(message);
    }

    public ServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * The error code.
     *
     * @return The error code.
     */
    public String getErrorCode() {
        return DEFAULT_ERROR_CODE;
    }

    /**
     * The HTTP error code associated with this error.
     *
     * @return The HTTP error code associated with this error.
     */
    public int getHttpErrorCode() {
        return DEFAULT_HTTP_ERROR_CODE;
    }

    /**
     * @return a comma-delimited list of details (key=value pairs)
     */
    public String getSummary() {
        StringBuilder builder = new StringBuilder();

        String error = this.getErrorCode();
        if (error != null) {
            builder.append("error=\"").append(error).append("\"").append(", ");
        }

        String errorMessage = this.getMessage();
        if (errorMessage != null) {
            builder.append("error_description=\"").append(errorMessage).append("\"");
        }

        return builder.toString();

    }

    @Override
    public String toString() {
        return getSummary();
    }
}