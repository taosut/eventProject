package vn.com.seabank.web.filter;

import org.springframework.web.filter.AbstractRequestLoggingFilter;

import javax.servlet.http.HttpServletRequest;

public class WebRequestTracingFilter  extends AbstractRequestLoggingFilter {


    public WebRequestTracingFilter() {
        this.setIncludeQueryString(true);
        this.setIncludePayload(true);
        this.setMaxPayloadLength(10000);
        this.setIncludeClientInfo(true);
        this.setIncludeHeaders(true);
    }

    @Override
    protected boolean shouldLog(HttpServletRequest request) {
        return this.logger.isTraceEnabled();
    }

    @Override
    protected void beforeRequest(HttpServletRequest request, String message) {
        this.logger.trace(String.format("%s %s", request.getMethod(), request.getRequestURI()));
    }

    @Override
    protected void afterRequest(HttpServletRequest request, String message) {
        this.logger.trace(message);
    }
}