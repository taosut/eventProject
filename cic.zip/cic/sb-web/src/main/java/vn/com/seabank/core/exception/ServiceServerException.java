package vn.com.seabank.core.exception;

/**
 * server internal error exception
 */
public abstract class ServiceServerException extends ServiceException {


    public ServiceServerException(String message) {
        super(message);
    }

    public ServiceServerException(String message, Throwable cause) {
        super(message, cause);
    }

    @Override
    public int getHttpErrorCode() {
        // The spec says this is a bad request (not unauthorized)
        return 500;
    }

    @Override
    public abstract String getErrorCode();


}
