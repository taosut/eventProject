package vn.com.seabank.core.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.domain.Page;

import java.io.Serializable;
import java.util.Collection;

/**
 * {
 *     data: {}
 *     page_meta:{
 *
 *     }
 * }
 */

public class PageResponseEntity  implements Serializable {

    @JsonProperty( value = "data")
    Collection<Serializable> data;

    @JsonProperty(value = "page_meta")
    PageMetaResponseEntity pageMetaResponseEntity;


    PageResponseEntity(Collection  data, PageMetaResponseEntity pageMetaResponseEntity) {
        this.data = data;
        this.pageMetaResponseEntity = pageMetaResponseEntity;
    }

    public static PageResponseEntity.PageResponseEntityBuilder builder() {
        return new PageResponseEntity.PageResponseEntityBuilder();
    }

    public Collection  getData() {
        return data;
    }

    public PageMetaResponseEntity getPageMetaResponseEntity() {
        return pageMetaResponseEntity;
    }

    @Override
    public String toString() {
        return "PageResponseEntity{" +
                "data=" + data +
                ", pageMetaResponseEntity=" + pageMetaResponseEntity +
                '}';
    }

    public static class PageResponseEntityBuilder {

        private Page page;

        PageResponseEntityBuilder() {
        }

        public PageResponseEntity.PageResponseEntityBuilder page(final Page page) {
            this.page = page;
            return this;
        }


        public PageResponseEntity build() {
            return new PageResponseEntity(
                    page.getContent(),
                    new PageMetaResponseEntity(
                            page.getNumber(),
                            page.getSize(),
                            page.getTotalElements(),
                            page.getTotalPages()
                    )
            );
        }

        @Override
        public String toString() {
            return "PageResponseEntityBuilder{" +
                    "page=" + page +
                    '}';
        }
    }
}
