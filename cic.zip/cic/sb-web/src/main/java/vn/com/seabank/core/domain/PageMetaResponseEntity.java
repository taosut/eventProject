package vn.com.seabank.core.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

/**
 *
 *  “page_meta”: {
         “page”:int,
         “size”: int,
         “total_elements”: int,
         “total_pages”: int
         }
 *
 */
public class PageMetaResponseEntity  implements Serializable {

    // paging
    @JsonProperty(value = "page")
    int page;

    @JsonProperty(value = "size")
    int size;

    @JsonProperty(value = "total_elements")
    long totalElements;

    @JsonProperty(value = "total_pages")
    int totalPages;

    // sorting


    public PageMetaResponseEntity(int page, int size, long totalElements, int totalPages) {
        this.page = page;
        this.size = size;
        this.totalElements = totalElements;
        this.totalPages = totalPages;
    }

    public int getPage() {
        return page;
    }


    public int getSize() {
        return size;
    }


    public long getTotalElements() {
        return totalElements;
    }


    public int getTotalPages() {
        return totalPages;
    }


    @Override
    public String toString() {
        return "PageMetaResponseEntity{" +
                "page=" + page +
                ", size=" + size +
                ", totalElements=" + totalElements +
                ", totalPages=" + totalPages +
                '}';
    }
}
