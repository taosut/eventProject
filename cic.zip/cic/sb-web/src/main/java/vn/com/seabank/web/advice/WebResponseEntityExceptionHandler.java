package vn.com.seabank.web.advice;


import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import vn.com.seabank.core.domain.ErrorFieldResponseEntity;
import vn.com.seabank.core.domain.ErrorResponseEntity;
import vn.com.seabank.core.exception.ServiceException;

import java.util.ArrayList;
import java.util.List;


public abstract class WebResponseEntityExceptionHandler extends org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler {


    // ##
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(ex, ex.getBindingResult(), headers, status, request);
    }

    // ##
    @Override
    protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        return handleExceptionInternal(ex, ex.getBindingResult(), headers, status, request);
    }
    @ExceptionHandler({ RuntimeException.class })
    protected ResponseEntity<Object> handleRuntimeException(RuntimeException ex, WebRequest request) {

        HttpHeaders headers = new HttpHeaders();
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        return handleExceptionInternal(ex, null, headers, status, request);

    }

    @ExceptionHandler({ ServiceException.class })
    protected ResponseEntity<Object> handleServiceException(ServiceException ex, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        HttpStatus status = HttpStatus.valueOf(ex.getHttpErrorCode());  // only valid for status that spec in http status table
        return handleExceptionInternal(ex, null, headers, status, request);
    }

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
        logger.trace("Oops !", ex);
        // rebuild body
        String error  = status.name().toLowerCase();
        String errorDescription = ex.getMessage(); // take default exception message
        List<ErrorFieldResponseEntity> errorFieldResponseEntities = new ArrayList<>();

        //
        if(ex instanceof ServiceException){
            ServiceException serviceException = (ServiceException) ex;
            error = serviceException.getErrorCode();
            errorDescription = serviceException.getMessage();
        }


        // case 1
        if(body instanceof BindingResult){
            BindingResult bindingResult = (BindingResult) body;

            //
            errorDescription = "validation error";
            //
            List<FieldError> fieldErrors = bindingResult.getFieldErrors();
            for (FieldError fieldError : fieldErrors) {
                errorFieldResponseEntities.add(new ErrorFieldResponseEntity(
                        fieldError.getField(), String.valueOf(fieldError.getRejectedValue()), fieldError.getDefaultMessage()
                ));
            }
        }
        // case X ...
        return super.handleExceptionInternal(
                ex,
                ErrorResponseEntity.builder()
                        .error(error)
                        .errorDescription(errorDescription)
                        .errorFields(errorFieldResponseEntities)
                        .build(),
                headers,
                status,
                request);

    }


}
