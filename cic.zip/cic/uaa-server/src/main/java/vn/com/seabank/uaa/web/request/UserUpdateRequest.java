package vn.com.seabank.uaa.web.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class UserUpdateRequest {

    @JsonProperty(value = "email")
    String email;

    @NotNull
    @JsonProperty(value = "email_verified")
    Boolean emailVerified;

    @JsonProperty(value = "mobile_number")
    String mobileNumber;

    @NotNull
    @JsonProperty(value = "mobile_verified")
    Boolean mobileNumberVerified;

    @NotNull
    @JsonProperty(value = "enabled")
    Boolean enabled;

    // basic info
    @JsonProperty(value = "nickname")
    String nickname;

    @JsonProperty(value = "first_name")
    String firstName;

    @JsonProperty(value = "last_name")
    String lastName;

    @JsonProperty(value = "gender")
    String gender;

    @JsonProperty(value = "birthday")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    Date birthday;

}
