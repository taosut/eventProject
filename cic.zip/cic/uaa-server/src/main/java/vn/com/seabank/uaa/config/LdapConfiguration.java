//package vn.com.seabank.uaa.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
///**
// * Created by ha.nv7 on 2/21/2019
// */
//@Configuration
//public class LdapConfiguration {
//    @Bean
//    public LdapContextSource contextSource () {
//        LdapContextSource contextSource= new LdapContextSource();
//        contextSource.setUrl(env.getRequiredProperty("ldap.url"));
//        contextSource.setBase(env.getRequiredProperty("ldap.base"));
//        contextSource.setUserDn(env.getRequiredProperty("ldap.user"));
//        contextSource.setPassword(env.getRequiredProperty("ldap.password"));
//        return contextSource;
//    }
//
//    @Bean
//    public LdapTemplate ldapTemplate() {
//        return new LdapTemplate(contextSource());
//    }
//}
