package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class RoleNotFoundException extends ServiceBadException {

    public RoleNotFoundException(String id) {
        super(String.format("Role %s is not found", id));
    }

    @Override
    public String getErrorCode() {
        return "ROLE_NOT_FOUND";
    }
}