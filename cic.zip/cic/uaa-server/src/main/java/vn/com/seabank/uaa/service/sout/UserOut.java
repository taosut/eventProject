package vn.com.seabank.uaa.service.sout;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.Date;

@Getter
@Builder
@ToString
public class UserOut {

    String id;
    String username;
    String email;
    Boolean emailVerified;
    String mobileNumber;
    Boolean mobileNumberVerified;
    String nickname;
    String password;
    Boolean enabled;
//    boolean credentialsNonExpired;
//    boolean accountNonExpired;
//    boolean accountNonLocked;
    String firstName;
    String lastName;
    String avatar;
    Date birthday;
    String gender;
//    Collection<RoleOut> roles;
    Date createdTime;
    String createdBy;
    Date modifiedTime;
    String modifiedBy;
}
