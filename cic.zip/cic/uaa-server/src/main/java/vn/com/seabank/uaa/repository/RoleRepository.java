package vn.com.seabank.uaa.repository;

import vn.com.seabank.uaa.domain.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, String> {


    //
    Optional<Role> findByName(String name);
    boolean existsByName(String name);

    //
    List<Role> findByNameIn(List<String> roleNames);

    //
    @Query(value = "select e from Role e" +
            " where  1 = 1 " +
            " and ( e.name = :keyword or :keyword is null)" +
            " and ( e.description = :keyword or :keyword is null)"
            )
    Page<Role> find(@Param(value = "keyword") String keyword, Pageable pageable);

}
