package vn.com.seabank.uaa.service.converter;


import vn.com.seabank.uaa.domain.User;
import vn.com.seabank.uaa.service.sout.UserOut;

import java.util.function.Function;

public class UserOutConverter implements Function<User, UserOut> {

    @Override
    public UserOut apply(User user) {
        return UserOut.builder()
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .emailVerified(user.isEmailVerified())
                .mobileNumber(user.getMobileNumber())
                .mobileNumberVerified(user.isMobileNumberVerified())
                .nickname(user.getNickname())
                .enabled(user.isEnabled())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .gender(user.getGender())
                .birthday(user.getBirthday())
                .avatar(user.getAvatar())
                .createdBy(user.getCreatedBy())
                .createdTime(user.getCreatedTime())
                .modifiedBy(user.getModifiedBy())
                .modifiedTime(user.getModifiedTime())
                .build();
    }
}
