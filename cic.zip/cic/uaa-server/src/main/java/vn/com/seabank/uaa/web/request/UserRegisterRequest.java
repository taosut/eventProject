package vn.com.seabank.uaa.web.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class UserRegisterRequest {

    @NotBlank
    @JsonProperty(value = "username")
    String username;

    @NotBlank
    @JsonProperty(value = "password")
    String password;

//    @JsonProperty(value = "enabled")
//    boolean enabled;

    // basic info
    @JsonProperty(value = "nickname")
    String nickname;

    @JsonProperty(value = "first_name")
    String firstName;

    @JsonProperty(value = "last_name")
    String lastName;

    @JsonProperty(value = "gender")
    String gender;

    @JsonProperty(value = "birthday")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    Date birthday;

}
