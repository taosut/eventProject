package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class UserEmailNotFoundException extends ServiceBadException {

    public UserEmailNotFoundException(String email) {
        super(String.format("Email %s is not found", email));
    }

    @Override
    public String getErrorCode() {
        return "EMAIL_NOT_FOUND";
    }
}