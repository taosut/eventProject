package vn.com.seabank.uaa.service.sin;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import java.util.Date;

@Getter
@ToString
@Builder
public class UserCreateIn {

    String username;
    String email;
    boolean emailVerified;
    String mobileNumber;
    boolean mobileNumberVerified;
    boolean enabled;
    //    boolean credentialsNonExpired;
    //    boolean accountNonLocked;
    //    boolean accountNonExpired;
    String nickname;
    String firstName;
    String lastName;
    //    String avatar;
    Date birthday;
    String gender;
//    Collection<RoleOut> roles;
}
