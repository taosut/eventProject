package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class UserGenderInvalidException extends ServiceBadException {

    public UserGenderInvalidException(String gender) {
        super(String.format("Gender %s is invalid", gender));
    }

    @Override
    public String getErrorCode() {
        return "GENRE_INVALID";
    }
}
