package vn.com.seabank.uaa.service.impl;

import vn.com.seabank.uaa.domain.Role;
import vn.com.seabank.uaa.exception.RoleNameDuplicateException;
import vn.com.seabank.uaa.exception.RoleNameNotFoundException;
import vn.com.seabank.uaa.exception.RoleNotFoundException;
import vn.com.seabank.uaa.repository.RoleRepository;
import vn.com.seabank.uaa.service.RoleService;
import vn.com.seabank.uaa.service.converter.RoleOutConverter;
import vn.com.seabank.uaa.service.sin.RoleCreateIn;
import vn.com.seabank.uaa.service.sin.RoleUpdateIn;
import vn.com.seabank.uaa.service.sout.RoleOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;


@Service
@Transactional
public class RoleServiceImpl implements RoleService {

    @Autowired
    RoleRepository roleRepository;


    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public RoleOut create(RoleCreateIn userCreateIn) throws RoleNameDuplicateException {
        return null;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public RoleOut update(RoleUpdateIn userUpdateIn) throws RoleNotFoundException {
        return null;
    }

    @Override
    @Transactional(readOnly = true)
    public RoleOut getById(String roleId) throws RoleNotFoundException {
        Optional<Role> roleOptional = roleRepository.findById(roleId);
        if (roleOptional.isPresent()){
            return new RoleOutConverter().apply(roleOptional.get());
        }
        throw new RoleNotFoundException(roleId);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsById(String roleId) {
        return roleRepository.existsById(roleId);
    }

    @Override
    @Transactional(readOnly = true)
    public RoleOut getByName(String name) throws RoleNameNotFoundException {
        Optional<Role> roleOptional = roleRepository.findByName(name);
        if (roleOptional.isPresent()){
            return new RoleOutConverter().apply(roleOptional.get());
        }
        throw new RoleNameNotFoundException(name);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsByName(String name) {
        return roleRepository.existsByName(name);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<RoleOut> getRoles(String keyword, Pageable pageable) {
        return roleRepository.find(keyword, pageable).map(new RoleOutConverter());
    }
}
