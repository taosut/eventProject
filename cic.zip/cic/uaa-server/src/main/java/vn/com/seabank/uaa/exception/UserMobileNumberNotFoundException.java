package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class UserMobileNumberNotFoundException extends ServiceBadException {

    public UserMobileNumberNotFoundException(String mobileNumber) {
        super(String.format("Mobile number %s is not found", mobileNumber));
    }

    @Override
    public String getErrorCode() {
        return "MOBILE_NUMBER_NOT_FOUND";
    }
}