package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class UserMobileNumberDuplicateException  extends ServiceBadException {

    public UserMobileNumberDuplicateException(String mobileNumber) {
        super(String.format("Mobile number %s is duplicated", mobileNumber));
    }

    @Override
    public String getErrorCode() {
        return "MOBILE_NUMBER_DUPLICATE";
    }
}