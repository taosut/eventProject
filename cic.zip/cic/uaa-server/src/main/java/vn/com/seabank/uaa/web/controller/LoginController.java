package vn.com.seabank.uaa.web.controller;


import io.swagger.annotations.ApiOperation;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import springfox.documentation.annotations.ApiIgnore;


@Controller
@ApiIgnore
public class LoginController {



    @RequestMapping(value = "login", method = RequestMethod.GET)
    @ApiOperation(value = "login page")
    public String getLogin() {
        return "login";
    }
}
