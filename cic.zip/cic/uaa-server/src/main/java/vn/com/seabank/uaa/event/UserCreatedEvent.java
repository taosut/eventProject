//package vn.com.seabank.uaa.event;
//
//import lombok.*;
//import org.springframework.context.PayloadApplicationEvent;
//
//@Setter
//@Getter
//@Builder
//@ToString
//public class UserCreatedEvent {
//
//    Long userId;
//    String nickname;
//
//}
