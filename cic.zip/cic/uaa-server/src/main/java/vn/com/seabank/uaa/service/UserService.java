package vn.com.seabank.uaa.service;

import vn.com.seabank.uaa.exception.UserEmailNotFoundException;
import vn.com.seabank.uaa.exception.UserMobileNumberNotFoundException;
import vn.com.seabank.uaa.exception.UserNotFoundException;
import vn.com.seabank.uaa.exception.UsernameDuplicateException;
import vn.com.seabank.uaa.service.sin.UserCreateIn;
import vn.com.seabank.uaa.service.sin.UserInfoUpdateIn;
import vn.com.seabank.uaa.service.sin.UserRegisterIn;
import vn.com.seabank.uaa.service.sin.UserUpdateIn;
import vn.com.seabank.uaa.service.sout.RoleOut;
import vn.com.seabank.uaa.service.sout.UserOut;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.List;


public interface UserService extends UserDetailsService{

    // add more method to load UserDetail
    UserDetails loadUserByEmail(String email) throws UserEmailNotFoundException;
    UserDetails loadUserByMobileNumber(String mobileNumber) throws UserMobileNumberNotFoundException;

    // load all authorities
//    Set<String> loadAuthoritiesByUsername(String username);

    //
    UserOut getById(String userId) throws UserNotFoundException;
    boolean existsById(String userId);
    //
    UserOut getByUsername(String username) throws UsernameNotFoundException;
    boolean existsByUsername(String username);

    //
    UserOut getByEmail(String email) throws UserEmailNotFoundException;
    boolean existByEmail(String email);

    //
    UserOut getByMobileNumber(String mobileNumber) throws UserMobileNumberNotFoundException;
    boolean existsByMobileNumber(String mobileNumber);

    //
    UserOut create(UserCreateIn userCreateIn) throws UsernameDuplicateException;
    UserOut update(UserUpdateIn userUpdateIn) throws UserNotFoundException;
    UserOut updateUserInfo(UserInfoUpdateIn userInfoUpdateIn) throws UserNotFoundException;


//    User changeNickname(String id, String nickname);
    void changeAvatar(String userId, String avatar) throws UserNotFoundException;
    void changePassword(String userId, String passwordPlainText) throws UserNotFoundException;

    //
    List<RoleOut> getRoles(String userId);
    void addRoles(String userId, List<String> roles);
    void removeRoles(String userId, List<String> roles);

    UserOut register(UserRegisterIn userRegisterIn);
}
