package vn.com.seabank.uaa.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "sec_role")
@EntityListeners(AuditingEntityListener.class)
public class Role {

    @Id
    @Column(name = "id", updatable = false)
    String id;

    @Column(name = "name", unique = true)
    String name;

    @Column(name = "description")
    @Nationalized
    String description;

    // === auditing
    @Column(name = "created_time")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    Date createdTime;

    @Column(name = "created_by")
    @CreatedBy
    String createdBy;

    @Column(name = "modified_time")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    Date modifiedTime;

    @Column(name = "modified_by")
    @LastModifiedBy
    String modifiedBy;

    @PrePersist
    public void prePersist(){
        this.id = UUID.randomUUID().toString();
    }

}
