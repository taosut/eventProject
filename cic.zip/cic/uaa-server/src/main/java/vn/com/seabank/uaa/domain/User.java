package vn.com.seabank.uaa.domain;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Collection;
import java.util.Date;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "sec_user")
@EntityListeners(AuditingEntityListener.class)
public class User  {

    @Id
    @Column(name = "id", updatable = false)
    String id;

    // auth info

    @Column(name = "username", unique = true)
    String username;

    @Column(name = "password")
    String password;

    @Column(name = "email", unique = true)
    String email;

    @Column(name = "email_verified", nullable = false)
    boolean emailVerified;

    @Column(name = "mobile_number", unique = true)
    String mobileNumber;

    @Column(name = "mobile_number_verified", nullable = false)
    boolean mobileNumberVerified;

    @Column(name = "enabled", nullable = false)
    boolean enabled;

    /*@Transient
    boolean credentialsNonExpired;

    @Transient
    boolean accountNonExpired;

    @Transient
    boolean accountNonLocked;*/

    // basic info
    @Column(name = "nickname")
    @Nationalized
    String nickname;

    @Column(name = "first_name")
    @Nationalized
    String firstName;

    @Column(name = "last_name")
    @Nationalized
    String lastName;

    @Column(name = "avatar")
    String avatar;

    @Column(name = "birthday")
    @Temporal(TemporalType.DATE)
    Date birthday;

    @Column(name = "gender")
    String gender;

    // == relationship mapping

    @JoinTable(name = "sec_user_role",
            joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"))
    @ManyToMany(fetch = FetchType.LAZY)
    Collection<Role> roles;

    // === auditing
    @Column(name = "created_time")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    Date createdTime;

    @Column(name = "created_by")
    @CreatedBy
    String createdBy;

    @Column(name = "modified_time")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    Date modifiedTime;

    @Column(name = "modified_by")
    @LastModifiedBy
    String modifiedBy;

    @PrePersist
    public void prePersist(){
        this.id = UUID.randomUUID().toString();
    }

/*    public  enum Status{
        ACTIVE, BLOCKED, BANNED;

        static public Status find(String value) {
            for (Status item : Status.values()) {
                if ( item.name().equalsIgnoreCase(value) ) return item;
            }
            throw new UserStatusInvalidException(value);
        }
    }*/

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", emailVerified=" + emailVerified +
                ", mobileNumber='" + mobileNumber + '\'' +
                ", mobileNumberVerified=" + mobileNumberVerified +
                ", nickname='" + nickname + '\'' +
                ", enabled=" + enabled +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", avatar='" + avatar + '\'' +
                ", birthday=" + birthday +
                ", gender='" + gender + '\'' +
                ", roles=" + roles +
                ", createdTime=" + createdTime +
                ", createdBy='" + createdBy + '\'' +
                ", modifiedTime=" + modifiedTime +
                ", modifiedBy='" + modifiedBy + '\'' +
                '}';
    }
}
