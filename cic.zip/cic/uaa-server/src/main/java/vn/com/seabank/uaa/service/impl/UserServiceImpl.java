package vn.com.seabank.uaa.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ldap.core.LdapTemplate;
import vn.com.seabank.uaa.domain.Role;
import vn.com.seabank.uaa.domain.User;
import vn.com.seabank.uaa.exception.*;
import vn.com.seabank.uaa.repository.RoleRepository;
import vn.com.seabank.uaa.repository.UserRepository;
import vn.com.seabank.uaa.service.UserService;
import vn.com.seabank.uaa.service.converter.RoleOutConverter;
import vn.com.seabank.uaa.service.converter.UserOutConverter;
import vn.com.seabank.uaa.service.sin.UserCreateIn;
import vn.com.seabank.uaa.service.sin.UserInfoUpdateIn;
import vn.com.seabank.uaa.service.sin.UserRegisterIn;
import vn.com.seabank.uaa.service.sin.UserUpdateIn;
import vn.com.seabank.uaa.service.sout.RoleOut;
import vn.com.seabank.uaa.service.sout.UserOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class UserServiceImpl implements UserService {


    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;


    @Autowired
    private LdapTemplate ldapTemplate;

    /**
     *  boolean enabled = true;
     *  boolean accountNonExpired = true;
     *  boolean credentialsNonExpired = true;
     *  boolean accountNonLocked = true;
     * @param username
     * @return
     * @throws UsernameNotFoundException
     */
    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> userOptional = userRepository.findByUsername(username);
//        Optional<User> userOptional = ldapTemplate.

        if (!userOptional.isPresent()) {
            String message = "user not found " + username;
            log.info(message);
            throw new UsernameNotFoundException(message);
        }

        User user = userOptional.get();
        log.debug("user found {} ", user.getUsername());

        // fetch all roles and permissions
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        for (Role role : user.getRoles()){
            authorities.add(new SimpleGrantedAuthority(role.getName()));
        }
        // create security user
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                user.isEnabled(),
                true,
                true,
                true,
                authorities
                );
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByMobileNumber(String mobileNumber) throws UserMobileNumberNotFoundException {
        Optional<User> userOptional = userRepository.findByMobileNumber(mobileNumber);
        if (!userOptional.isPresent()) {
            String message = "user not found " + mobileNumber;
            log.info(message);
            throw new UsernameNotFoundException(message);
        }

        User user = userOptional.get();
        log.debug("user found {} ", user.getUsername());

        // fetch all roles and permissions
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        for (Role role : user.getRoles()){
            authorities.add(new SimpleGrantedAuthority(role.getName()));
        }
        // create security user
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                user.isEnabled(),
                true,
                true,
                true,
                authorities
        );
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByEmail(String email) throws UserEmailNotFoundException {
        Optional<User> userOptional = userRepository.findByEmail(email);
        if (!userOptional.isPresent()) {
            String message = "user not found " + email;
            log.info(message);
            throw new UsernameNotFoundException(message);
        }

        User user = userOptional.get();
        log.debug("user found {} ", user.getUsername());

        // fetch all roles and permissions
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        for (Role role : user.getRoles()){
            authorities.add(new SimpleGrantedAuthority(role.getName()));
        }
        // create security user
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                user.isEnabled(),
                true,
                true,
                true,
                authorities
        );
    }


    @Override
    @Transactional(readOnly = true)
    public boolean existsById(String userId) {
        return userRepository.existsById(userId);
    }

    @Override
    @Transactional(readOnly = true)
    public UserOut getById(String userId) throws UserNotFoundException {
        Optional<User> userOptional = userRepository.findById(userId);
        if(userOptional.isPresent()){
            return new UserOutConverter().apply(userOptional.get());
        }
        throw new UserNotFoundException(userId);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }

    @Override
    @Transactional(readOnly = true)
    public UserOut getByUsername(String username) throws UsernameNotFoundException {
        Optional<User> userOptional = userRepository.findByUsername(username);
        if(userOptional.isPresent()){
            return new UserOutConverter().apply(userOptional.get());
        }
        throw new UsernameNotFoundException(username);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existByEmail(String email) {
        return userRepository.existsByEmail(email);
    }

    @Override
    @Transactional(readOnly = true)
    public UserOut getByEmail(String email) throws UserEmailNotFoundException{
        Optional<User> userOptional = userRepository.findByEmail(email);
        if(userOptional.isPresent()){
            return new UserOutConverter().apply(userOptional.get());
        }
        throw new UserEmailNotFoundException(email);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsByMobileNumber(String mobileNumber) {
        return userRepository.existsByMobileNumber(mobileNumber);
    }

    @Override
    @Transactional(readOnly = true)
    public UserOut getByMobileNumber(String mobileNumber) throws UserMobileNumberNotFoundException{
        Optional<User> userOptional = userRepository.findByMobileNumber(mobileNumber);
        if(userOptional.isPresent()){
            return new UserOutConverter().apply(userOptional.get());
        }
        throw new UserMobileNumberNotFoundException(mobileNumber);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public UserOut create(UserCreateIn userCreateIn) {
        // username validate
        if(userCreateIn.getUsername()!= null
                && userRepository.existsByUsername(userCreateIn.getUsername())){
            throw new UsernameDuplicateException(userCreateIn.getUsername());
        }
        // email validate
        if(userCreateIn.getEmail()!= null
                && userRepository.existsByEmail(userCreateIn.getEmail())){
            throw new UserEmailDuplicateException(userCreateIn.getEmail());
        }
        // mobile number validate
        if(userCreateIn.getMobileNumber()!= null
                && userRepository.existsByMobileNumber(userCreateIn.getMobileNumber())){
            throw new UserMobileNumberDuplicateException(userCreateIn.getMobileNumber());
        }

        // create new user
        User user = new User();
        user.setUsername(userCreateIn.getUsername());
        user.setEmail(userCreateIn.getEmail());
        user.setMobileNumber(userCreateIn.getMobileNumber());
        user.setNickname(userCreateIn.getNickname());
        user.setEnabled(userCreateIn.isEnabled());
        user.setFirstName(userCreateIn.getFirstName());
        user.setLastName(userCreateIn.getLastName());
        user.setBirthday(userCreateIn.getBirthday());
        user.setGender(userCreateIn.getGender());

        user = userRepository.save(user);
        return new UserOutConverter().apply(user);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public UserOut update(UserUpdateIn userUpdateIn) {
        // validate by user id
        Optional<User> userOptional = userRepository.findById(userUpdateIn.getId());
        if(!userOptional.isPresent()){
            throw new UserNotFoundException(userUpdateIn.getId());
        }
        // update user info
        User user = userOptional.get();
        //
//        user.setUsername(userUpdateIn.getUsername());
        user.setEmail(userUpdateIn.getEmail());
        user.setEmailVerified(userUpdateIn.isEmailVerified());
        user.setMobileNumber(userUpdateIn.getMobileNumber());
        user.setMobileNumberVerified(userUpdateIn.isMobileNumberVerified());
        user.setEnabled(userUpdateIn.isEnabled());

        user.setNickname(userUpdateIn.getNickname());
        user.setFirstName(userUpdateIn.getFirstName());
        user.setLastName(userUpdateIn.getLastName());
        user.setBirthday(userUpdateIn.getBirthday());
        user.setGender(userUpdateIn.getGender());

        user = userRepository.save(user);
        return new UserOutConverter().apply(user);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public UserOut updateUserInfo(UserInfoUpdateIn userInfoUpdateIn) {
        // validate by user id
        Optional<User> userOptional = userRepository.findById(userInfoUpdateIn.getId());
        if(!userOptional.isPresent()){
            throw new UserNotFoundException(userInfoUpdateIn.getId());
        }
        // update user info
        User user = userOptional.get();
        //
        user.setNickname(userInfoUpdateIn.getNickname());
        user.setFirstName(userInfoUpdateIn.getFirstName());
        user.setLastName(userInfoUpdateIn.getLastName());
        user.setBirthday(userInfoUpdateIn.getBirthday());
        user.setGender(userInfoUpdateIn.getGender());

        user = userRepository.save(user);
        return new UserOutConverter().apply(user);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void changeAvatar(String userId, String avatar) throws UserNotFoundException{
        Optional<User> userOptional = userRepository.findById(userId);
        if(userOptional.isPresent()){
            User user = userOptional.get();
            user.setAvatar(avatar);
            userRepository.save(user);
            return;
        }
        throw new UserNotFoundException(String.valueOf(userId));
    }


    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void changePassword(String userId, String passwordPlainText) throws UserNotFoundException{
        Optional<User> userOptional = userRepository.findById(userId);
        if(userOptional.isPresent()){
            User user = userOptional.get();
            user.setPassword(passwordEncoder.encode(passwordPlainText));
            userRepository.save(user);
            return;
        }
        throw new UserNotFoundException(String.valueOf(userId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<RoleOut> getRoles(String userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        if(userOptional.isPresent()){
            User user = userOptional.get();
            return user.getRoles().stream().map(new RoleOutConverter()).collect(Collectors.toList());
        }
        throw new UserNotFoundException(String.valueOf(userId));
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void addRoles(String userId, List<String> roles) {
        Optional<User> userOptional = userRepository.findById(userId);
        if(userOptional.isPresent()){
            User user = userOptional.get();
            Collection<Role> userRoles = user.getRoles();
            List<Role> roleList = roleRepository.findByNameIn(roles);
            userRoles.addAll(roleList);
            userRepository.save(user);
            return;
        }
        throw new UserNotFoundException(String.valueOf(userId));
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void removeRoles(String userId, List<String> roles) {
        Optional<User> userOptional = userRepository.findById(userId);
        if(userOptional.isPresent()){
            User user = userOptional.get();
            Collection<Role> userRoles = user.getRoles();
            List<Role> roleList = roleRepository.findByNameIn(roles);
            userRoles.removeAll(roleList);
            userRepository.save(user);
            return;
        }
        throw new UserNotFoundException(String.valueOf(userId));
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public UserOut register(UserRegisterIn userRegisterIn) {
        // username validate
        if(userRepository.existsByUsername(userRegisterIn.getUsername())){
            throw new UsernameDuplicateException(userRegisterIn.getUsername());
        }
        //  create new user
        User user = new User();
        user.setUsername(userRegisterIn.getUsername());
        user.setPassword(passwordEncoder.encode(userRegisterIn.getPassword()));
        user.setEnabled(userRegisterIn.isEnabled());
        //
        user.setNickname(userRegisterIn.getNickname());
        user.setFirstName(userRegisterIn.getFirstName());
        user.setLastName(userRegisterIn.getLastName());
        user.setBirthday(userRegisterIn.getBirthday());
        user.setGender(userRegisterIn.getGender());

        user = userRepository.save(user);
        return new UserOutConverter().apply(user);
    }
}
