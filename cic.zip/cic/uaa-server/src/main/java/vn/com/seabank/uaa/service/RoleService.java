package vn.com.seabank.uaa.service;

import vn.com.seabank.uaa.exception.*;
import vn.com.seabank.uaa.service.sin.RoleCreateIn;
import vn.com.seabank.uaa.service.sin.RoleUpdateIn;
import vn.com.seabank.uaa.service.sout.RoleOut;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


public interface RoleService{

    //
    RoleOut create(RoleCreateIn userCreateIn) throws RoleNameDuplicateException;
    RoleOut update(RoleUpdateIn userUpdateIn) throws RoleNotFoundException;


    //
    RoleOut getById(String roleId) throws RoleNotFoundException;
    boolean existsById(String roleId);
    //
    RoleOut getByName(String name) throws RoleNameNotFoundException;
    boolean existsByName(String name);
    //
    Page<RoleOut> getRoles(String keyword, Pageable pageable);

}
