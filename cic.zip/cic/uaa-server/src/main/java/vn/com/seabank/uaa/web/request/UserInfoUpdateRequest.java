package vn.com.seabank.uaa.web.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class UserInfoUpdateRequest {

    @JsonProperty(value = "nickname")
    String nickname;

    @JsonProperty(value = "first_name")
    String firstName;

    @JsonProperty(value = "last_name")
    String lastName;

    @JsonProperty(value = "gender")
    String gender;

    @JsonProperty(value = "birthday")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    Date birthday;
}
