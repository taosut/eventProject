package vn.com.seabank.uaa.web.converter;

import vn.com.seabank.uaa.service.sout.RoleOut;
import vn.com.seabank.uaa.web.response.RoleResponse;

import java.util.function.Function;

public class RoleResponseConverter implements Function<RoleOut, RoleResponse> {


    @Override
    public RoleResponse apply(RoleOut roleOut) {
        return RoleResponse.builder()
                .id(roleOut.getId())
                .name(roleOut.getName())
                .description(roleOut.getDescription())
                .createdBy(roleOut.getCreatedBy())
                .createdTime(roleOut.getCreatedTime())
                .modifiedBy(roleOut.getModifiedBy())
                .modifiedTime(roleOut.getModifiedTime())
                .build();
    }
}
