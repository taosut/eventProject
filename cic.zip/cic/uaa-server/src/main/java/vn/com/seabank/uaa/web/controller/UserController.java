package vn.com.seabank.uaa.web.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import vn.com.seabank.uaa.exception.UserNotFoundException;
import vn.com.seabank.uaa.exception.UserPasswordNotMatchesException;
import vn.com.seabank.uaa.service.UserService;
import vn.com.seabank.uaa.service.sin.UserCreateIn;
import vn.com.seabank.uaa.service.sin.UserRegisterIn;
import vn.com.seabank.uaa.service.sin.UserUpdateIn;
import vn.com.seabank.uaa.service.sout.RoleOut;
import vn.com.seabank.uaa.service.sout.UserOut;
import vn.com.seabank.uaa.web.converter.RoleResponseConverter;
import vn.com.seabank.uaa.web.converter.UserResponseConverter;
import vn.com.seabank.uaa.web.request.*;
import vn.com.seabank.uaa.web.response.RoleResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;


@Slf4j
@Api(tags = "User", description = "users endpoint")
@RestController
@RequestMapping(value = "users")
public class UserController {


    @Autowired
    UserService userService;

    @Autowired
    PasswordEncoder passwordEncoder;


    @GetMapping(value = "check-username")
    @ApiOperation(value = "check user by username")
    public ResponseEntity<?> getCheckUsername(
            @RequestParam(value = "username") String username
    ){
        if(userService.existsByUsername(username)){
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.noContent().build();
    }

    @GetMapping(value = "check-email")
    @ApiOperation(value = "check user by email")
    public ResponseEntity<?> getCheckMail(
            @RequestParam(value = "email") String email
    ){
        if(userService.existByEmail(email)){
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.noContent().build();
    }

    @GetMapping(value = "check-mobile-number")
    @ApiOperation(value = "check user by mobile number")
    public ResponseEntity<?> getCheckMobileNumber(
            @RequestParam(value = "mobile_number") String mobileNumber
    ){
        if(userService.existsByMobileNumber(mobileNumber)){
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    @ApiOperation(value = "create new user")
    public ResponseEntity<?> postCreateUser(
            @RequestBody @Valid UserCreateRequest userCreateRequest
    ){
        //
        UserCreateIn userCreateIn = UserCreateIn.builder()
                // transform
                .username(userCreateRequest.getUsername())
                .email(userCreateRequest.getEmail())
                .emailVerified(userCreateRequest.getEmailVerified())
                .mobileNumber(userCreateRequest.getMobileNumber())
                .mobileNumberVerified(userCreateRequest.getMobileNumberVerified())
                .enabled(userCreateRequest.getEnabled())
                //
                .nickname(userCreateRequest.getNickname())
                .firstName(userCreateRequest.getFirstName())
                .lastName(userCreateRequest.getLastName())
                .birthday(userCreateRequest.getBirthday())
                .gender(userCreateRequest.getGender())
                .build();
        //
        UserOut userOut = userService.create(userCreateIn);
        log.info("user created ", userOut);
        return ResponseEntity.ok(new UserResponseConverter().apply(userOut));
    }

    @PutMapping(value = "{user_id}")
    @ApiOperation(value = "update user info")
    public ResponseEntity<?> putUpdateUser(
            @PathVariable(value = "user_id") String userId,
            @RequestBody @Valid UserUpdateRequest userUpdateRequest
    ){
        //
        UserUpdateIn userUpdateIn = UserUpdateIn.builder()
                // transform
//                .username(userUpdateRequest.getUsername())
                .email(userUpdateRequest.getEmail())
                .emailVerified(userUpdateRequest.getEmailVerified())
                .mobileNumber(userUpdateRequest.getMobileNumber())
                .mobileNumberVerified(userUpdateRequest.getMobileNumberVerified())
                .enabled(userUpdateRequest.getEnabled())
                //
                .nickname(userUpdateRequest.getNickname())
                .firstName(userUpdateRequest.getFirstName())
                .lastName(userUpdateRequest.getLastName())
                .birthday(userUpdateRequest.getBirthday())
                .gender(userUpdateRequest.getGender())
                // enrich
                .id(userId)
                .build();
        //
        UserOut userOut = userService.update(userUpdateIn);
        log.info("user updated ", userOut);
        return ResponseEntity.ok(new UserResponseConverter().apply(userOut));
    }


    // ###################### user functions

    @PutMapping(value = "{user_id}/reset-password")
    @ApiOperation(value = "reset password")
    public ResponseEntity<?> putResetPassword(
            @PathVariable(value = "user_id") String userId,
            @RequestBody @Valid UserPasswordResetRequest userPasswordResetRequest
    ){
        userService.changePassword(userId, userPasswordResetRequest.getPassword());
        log.trace("password updated ", userId);
        return ResponseEntity.ok().build();
    }

    // add/remove/list roles of the user
    @GetMapping(value = "{user_id}/roles")
    @ApiOperation(value = "list all role of user")
    public ResponseEntity<?> getRolesOfUser(
            @PathVariable(value = "user_id") String userId
    ){
        //
        List<RoleResponse> roleResponseList = new ArrayList<>();
        //
        for(RoleOut roleOut: userService.getRoles(userId)){
            roleResponseList.add(new RoleResponseConverter().apply(roleOut));
        }
        return ResponseEntity.ok(roleResponseList);
    }

    @PostMapping(value = "{user_id}/roles")
    @ApiOperation(value = "add new role to user")
    public ResponseEntity<?> postAddRole2User(
            @PathVariable(value = "user_id") String userId,
            @RequestBody List<String> roleNames
            ){
        //
        userService.addRoles(userId, roleNames);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping(value = "{user_id}/roles")
    @ApiOperation(value = "remove role from user")
    public ResponseEntity<?> deleteAddRole2User(
            @PathVariable(value = "user_id") String userId,
            @RequestBody List<String> roleNames
    ){
        // validate
        if(!userService.existsById(userId)){
            throw new UserNotFoundException(userId);
        }
        //
        userService.removeRoles(userId, roleNames);
        return ResponseEntity.ok().build();
    }


    ///

    @PostMapping(value = "register")
    @ApiOperation(value = "user register")
    public ResponseEntity<?> postRegisterUser(
            @RequestBody @Valid UserRegisterRequest userRegisterRequest
    ){
        //
        if(userService.existsByUsername(userRegisterRequest.getUsername())){
            UserOut userOut = userService.getByUsername(userRegisterRequest.getUsername());
            log.info("user has already been created ", userOut);
            return ResponseEntity.ok(new UserResponseConverter().apply(userOut));
        }
        // new user
        UserRegisterIn userRegisterIn = UserRegisterIn.builder()
                // transform
                .username(userRegisterRequest.getUsername())
                .password(userRegisterRequest.getPassword())
//                .enabled(userRegisterRequest.isEnabled())
                .enabled(true)
                //
                .nickname(userRegisterRequest.getNickname())
                .firstName(userRegisterRequest.getFirstName())
                .lastName(userRegisterRequest.getLastName())
                .birthday(userRegisterRequest.getBirthday())
                .gender(userRegisterRequest.getGender())
                .build();
        //
        UserOut userOut = userService.register(userRegisterIn);
        log.info("user created ", userOut);
        return ResponseEntity.ok(new UserResponseConverter().apply(userOut));
    }

}
