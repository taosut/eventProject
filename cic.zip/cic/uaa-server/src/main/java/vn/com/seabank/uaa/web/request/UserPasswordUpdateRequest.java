package vn.com.seabank.uaa.web.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class UserPasswordUpdateRequest {

    @JsonProperty(value = "pass_old")
    String passOld;

    @JsonProperty(value = "pass_new")
    String passNew;


}
