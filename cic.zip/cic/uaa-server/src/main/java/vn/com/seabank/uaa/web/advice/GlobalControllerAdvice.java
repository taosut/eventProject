package vn.com.seabank.uaa.web.advice;

import lombok.extern.slf4j.Slf4j;
import vn.com.seabank.web.advice.WebResponseEntityExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@Slf4j
@RestControllerAdvice
public class GlobalControllerAdvice extends WebResponseEntityExceptionHandler {


}
