package vn.com.seabank.uaa.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by ha.nv7 on 2/21/2019
 */

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "sec_employee")
@EntityListeners(AuditingEntityListener.class)
public class Employee {

    @Id
    @Column(name = "id", updatable = false)
    String id;

    @Column(name = "code", nullable = false)
    String code;

    @Column(name = "profile_link", nullable = false)
    String profileLink;

    @Column(name = "area")
    String area;

    @Column(name = "created_time")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    Date createdTime;

    @Column(name = "created_by")
    @CreatedBy
    String createdBy;

    @Column(name = "modified_time")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    Date modifiedTime;

    @Column(name = "modified_by")
    @LastModifiedBy
    String modifiedBy;

    @OneToOne
    @MapsId
    User user;

    @Override
    public String toString() {
        return "Employee{" +
                "id='" + id + '\'' +
                ", code='" + code + '\'' +
                ", profileLink='" + profileLink + '\'' +
                ", area='" + area + '\'' +
                ", createdTime=" + createdTime +
                ", createdBy='" + createdBy + '\'' +
                ", modifiedTime=" + modifiedTime +
                ", modifiedBy='" + modifiedBy + '\'' +
                '}';
    }
}
