package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class UserNotFoundException extends ServiceBadException {

    public UserNotFoundException(String id) {
        super(String.format("User %s is not found", id));
    }

    @Override
    public String getErrorCode() {
        return "USER_NOT_FOUND";
    }
}