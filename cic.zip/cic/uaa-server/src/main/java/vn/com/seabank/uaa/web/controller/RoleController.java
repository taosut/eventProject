package vn.com.seabank.uaa.web.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import vn.com.seabank.uaa.service.RoleService;
import vn.com.seabank.uaa.service.sin.RoleCreateIn;
import vn.com.seabank.uaa.service.sin.RoleUpdateIn;
import vn.com.seabank.uaa.service.sout.RoleOut;
import vn.com.seabank.uaa.web.converter.RoleResponseConverter;
import vn.com.seabank.uaa.web.request.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@Slf4j
@Api(tags = "Role", description = "roles endpoint")
@RestController
@RequestMapping(value = "roles")
public class RoleController {

    @Autowired
    RoleService roleService;

    @PostMapping
    @ApiOperation(value = "create new role")
    public ResponseEntity<?> postCreateRole(
            @RequestBody @Valid RoleCreateRequest roleCreateRequest
    ){
        //
        RoleCreateIn userCreateIn = RoleCreateIn.builder()
                // transform
                .name(roleCreateRequest.getName())
                .description(roleCreateRequest.getDescription())
                .build();
        //
        RoleOut roleOut = roleService.create(userCreateIn);
        log.info("role created ", roleOut);
        return ResponseEntity.ok(new RoleResponseConverter().apply(roleOut));
    }

    @PutMapping(value = "{role_id}")
    @ApiOperation(value = "update role")
    public ResponseEntity<?> putUpdateRole(
            @PathVariable(value = "role_id") String roleId,
            @RequestBody @Valid RoleUpdateRequest roleUpdateRequest
    ){
        //
        RoleUpdateIn roleUpdateIn = RoleUpdateIn.builder()
                // transform
                .name(roleUpdateRequest.getName())
                .description(roleUpdateRequest.getDescription())
                // enrich
                .id(roleId)
                .build();
        //
        RoleOut roleOut = roleService.update(roleUpdateIn);
        log.info("role updated ", roleOut);
        return ResponseEntity.ok(new RoleResponseConverter().apply(roleOut));
    }



}
