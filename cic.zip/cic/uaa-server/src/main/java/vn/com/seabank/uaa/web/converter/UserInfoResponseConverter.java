package vn.com.seabank.uaa.web.converter;

import vn.com.seabank.uaa.service.sout.UserOut;
import vn.com.seabank.uaa.web.response.UserInfoResponse;

import java.util.function.Function;

public class UserInfoResponseConverter implements Function<UserOut, UserInfoResponse> {

	@Override
	public UserInfoResponse apply(UserOut user) {
		UserInfoResponse userInfoResponse = UserInfoResponse.builder()
				.id(user.getId())
				.username(user.getUsername())
				.email(user.getEmail())
				.mobileNumber(user.getMobileNumber())
				.nickname(user.getNickname())
				.firstName(user.getFirstName())
				.lastName(user.getLastName())
				.birthday(user.getBirthday())
				.gender(user.getGender())
				.avatar(user.getAvatar())
				.build();
		return userInfoResponse;
	}

}
