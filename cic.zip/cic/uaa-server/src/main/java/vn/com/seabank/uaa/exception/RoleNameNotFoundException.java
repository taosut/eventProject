package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class RoleNameNotFoundException extends ServiceBadException {

    public RoleNameNotFoundException(String name) {
        super(String.format("Role %s is not found", name));
    }

    @Override
    public String getErrorCode() {
        return "ROLE_NAME_NOT_FOUND";
    }
}