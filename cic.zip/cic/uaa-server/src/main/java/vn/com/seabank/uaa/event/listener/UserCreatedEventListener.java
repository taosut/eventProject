//package vn.com.seabank.uaa.event.listener;
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.context.ApplicationListener;
//import org.springframework.stereotype.Component;
//
//import vn.com.seabank.uaa.event.UserCreatedEvent;
//
//
//@Slf4j
//public class UserCreatedEventListener implements ApplicationListener<UserCreatedEvent> {
//
//    @Override
//    public void onApplicationEvent(UserCreatedEvent event) {
//        log.info("New user created ID {}, {}", event.getUserId(), event.getNickname());
//    }
//}
