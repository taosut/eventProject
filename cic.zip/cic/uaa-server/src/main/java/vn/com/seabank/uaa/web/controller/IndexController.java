package vn.com.seabank.uaa.web.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import springfox.documentation.annotations.ApiIgnore;


@Controller
@ApiIgnore
public class IndexController {


    @RequestMapping(value = "/", method = RequestMethod.GET)
    @ApiOperation(value = "root / page")
    public String getIndex() {
        return "redirect:/index";
    }

    @RequestMapping(value = "index", method = RequestMethod.GET)
    @ApiOperation(value = "index page")
    public String getIndex1() {
        return "index";
    }
}
