package vn.com.seabank.uaa.web.response;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Date;
import java.util.Set;

@Getter
@Setter
@Builder
@ToString
public class UserInfoResponse {

    @JsonProperty(value = "id")
	String id;

    @JsonProperty(value = "username")
    String username;

    @JsonProperty(value = "email")
    String email;

    @JsonProperty(value = "mobile_number")
    String mobileNumber;

    @JsonProperty(value = "nickname")
    String nickname;

    @JsonProperty(value = "avatar")
    String avatar;

    @JsonProperty(value = "first_name")
    String firstName;

    @JsonProperty(value = "last_name")
    String lastName;

    @JsonProperty(value = "gender")
    String gender;

    @JsonProperty(value = "birthday")
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    Date birthday;

    @JsonProperty(value = "authorities")
    Set<String> authorities;

}
