package vn.com.seabank.uaa.web.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.Date;

@Getter
@Builder
@ToString
public class RoleResponse {


    @JsonProperty(value = "id")
    String id;

    @JsonProperty(value = "name")
    String name;

    @JsonProperty(value = "description")
    String description;

    @JsonProperty(value = "created_by")
    String createdBy;

    @JsonProperty(value = "created_time")
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    Date createdTime;

    @JsonProperty(value = "modified_by")
    String modifiedBy;

    @JsonProperty(value = "modified_time")
    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    Date modifiedTime;
}
