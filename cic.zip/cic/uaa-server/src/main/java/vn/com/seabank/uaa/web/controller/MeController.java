package vn.com.seabank.uaa.web.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import vn.com.seabank.core.exception.ServiceException;
import vn.com.seabank.uaa.exception.UserPasswordNotMatchesException;
import vn.com.seabank.uaa.service.UserService;
import vn.com.seabank.uaa.service.sin.UserInfoUpdateIn;
import vn.com.seabank.uaa.service.sout.UserOut;
import vn.com.seabank.uaa.web.converter.UserInfoResponseConverter;
import vn.com.seabank.uaa.web.request.UserInfoUpdateRequest;
import vn.com.seabank.uaa.web.request.UserPasswordUpdateRequest;
import vn.com.seabank.uaa.web.response.AvatarResponse;
import vn.com.seabank.uaa.web.response.UserInfoResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.security.Principal;
import java.util.*;

@Slf4j
@Api(tags = "Me", description = "me endpoint")
@RestController
@RequestMapping(value = "me")
public class MeController {

    @Value("${my-app.user.avatar-base-dir}")
    String userAvatarBaseDir;

    @Autowired
    UserService userService;

    @Autowired
    DefaultTokenServices defaultTokenServices;


    @Autowired
    PasswordEncoder passwordEncoder;


    @GetMapping
    @ApiOperation(value = "oauth2 user info")
    public ResponseEntity<?>  getMe(Principal principal) {
        String principalName = principal.getName();
        UserOut userOut = userService.getByUsername(principalName);
        // basic info
        UserInfoResponse userInfoResponse = new UserInfoResponseConverter().apply(userOut);

        // fetch all authorities
        Set<String> authorities = new HashSet<>();
        userInfoResponse.setAuthorities(authorities);
        //
        UserDetails userDetails = userService.loadUserByUsername(principalName);
        userDetails.getAuthorities().forEach(item -> {
            authorities.add(item.getAuthority());
        });
        //
        return ResponseEntity.ok(userInfoResponse);
    }


    @DeleteMapping(value = "logout")
    @ApiOperation(value = "oauth2 user logout")
    public ResponseEntity<?> deleteToken(
            @RequestParam(value = "token") String token){
        defaultTokenServices.revokeToken(token);
        log.trace("token removed ", token);
        return ResponseEntity.ok().build();
    }

    @PutMapping(value = "avatar")
    @ApiOperation(value = "change avatar")
    public ResponseEntity<?> putAvatar(
            @RequestPart(value = "file") MultipartFile fileUpload,
            Principal principal) throws IOException {
        String principalName = principal.getName();
        UserOut userOut = userService.getByUsername(principalName);

        // create base dir, eg /data/images
        File imageBaseDir = new File(this.userAvatarBaseDir);
        if(!imageBaseDir.exists()) {
            imageBaseDir.mkdirs();
            log.info("image dir created", imageBaseDir.getAbsolutePath());
        }

        // get file extension
        String originalFilename = fileUpload.getOriginalFilename();
        log.trace("original file name ", originalFilename);

        String fileExtension = originalFilename.lastIndexOf(".") == -1
                || originalFilename.lastIndexOf(".") == 0
                ? "" : originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        fileExtension = fileExtension == null ? "png" : fileExtension;

        //build avatar dir with format: avatar/year/month/UUID.png|jpg
        StringBuilder avatarDirBuilder = new StringBuilder();
        avatarDirBuilder.append(Calendar.getInstance().get(Calendar.YEAR));
        avatarDirBuilder.append(FileSystems.getDefault().getSeparator());
        avatarDirBuilder.append(Calendar.getInstance().get(Calendar.MONTH) + 1);
        avatarDirBuilder.append(FileSystems.getDefault().getSeparator());
        // make avatar dir if it's not exist
        File avatarDir = new File(imageBaseDir, avatarDirBuilder.toString());
        if(!avatarDir.exists()) {
            avatarDir.mkdirs();
            log.info("avatar dir created ", avatarDir.getAbsolutePath());
        }

        // complete avatar file with file name
       String avatarFileName = String.format("%s.%s", UUID.randomUUID().toString(), fileExtension);
       avatarDirBuilder.append(avatarFileName);
       log.trace("avatar file ", avatarDirBuilder.toString());

        // make final avatar file
        File avatarFile = new File(imageBaseDir, avatarDirBuilder.toString());
        log.trace("exec transfer upload file to {}", avatarFile.getAbsolutePath());
        try {
            fileUpload.transferTo(avatarFile.getAbsoluteFile());
            //
            userService.changeAvatar( userOut.getId(), avatarDirBuilder.toString());
            //
            log.trace("avatar changed ", avatarDirBuilder.toString());
            //
            return ResponseEntity.ok(AvatarResponse.builder()
                    .id(userOut.getId())
                    .avatar(avatarDirBuilder.toString())
                    .build());
        } catch (IOException e) {
            throw new ServiceException("Oops! File transfer exception", e);
        }

    }

    @PutMapping
    @ApiOperation(value = "update user info")
    public ResponseEntity<?> putUserInfo(
            Principal principal,
            @RequestBody @Valid UserInfoUpdateRequest userInfoUpdateRequest
    ){
        String principalName = principal.getName();
        UserOut userOut = userService.getByUsername(principalName);
        //
        UserInfoUpdateIn userInfoUpdateIn = UserInfoUpdateIn.builder()
                // transform
                .nickname(userInfoUpdateRequest.getNickname())
                .firstName(userInfoUpdateRequest.getFirstName())
                .lastName(userInfoUpdateRequest.getLastName())
                .birthday(userInfoUpdateRequest.getBirthday())
                .gender(userInfoUpdateRequest.getGender())
                // enrich
                .id(userOut.getId())
                .build();
        userOut = userService.updateUserInfo(userInfoUpdateIn);
        log.trace("user info updated ", userOut);
        return ResponseEntity.ok(new UserInfoResponseConverter().apply(userOut));
    }



    @PutMapping(value = "password")
    @ApiOperation(value = "change password")
    public ResponseEntity<?> putChangePassword(
            Principal principal,
            @RequestBody @Valid UserPasswordUpdateRequest userPasswordUpdateRequest
    ){
        String principalName = principal.getName();
        UserOut userOut = userService.getByUsername(principalName);
        // verify old pass
        if(passwordEncoder.matches(userPasswordUpdateRequest.getPassOld(), userOut.getPassword())){
            // update new pass
            String passNewEncoded = passwordEncoder.encode(userPasswordUpdateRequest.getPassNew());
            userService.changePassword(userOut.getId(), passNewEncoded);
            log.trace("password updated ", userOut.getId());
            return ResponseEntity.ok().build();
        }
        throw new UserPasswordNotMatchesException(principalName);
    }

}
