package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class RoleNameDuplicateException extends ServiceBadException {

    public RoleNameDuplicateException(String name) {
        super(String.format("Role %s is duplicated", name));
    }

    @Override
    public String getErrorCode() {
        return "ROLE_NAME_DUPLICATE";
    }
}