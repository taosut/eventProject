package vn.com.seabank.uaa.service.sin;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.Date;

@Getter
@ToString
@Builder
public class UserRegisterIn {

    String username;
    String password;
    boolean enabled;
//
    String nickname;
    String firstName;
    String lastName;
    Date birthday;
    String gender;
}
