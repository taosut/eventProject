package vn.com.seabank.uaa.service.sout;


import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.Date;

@Getter
@Builder
@ToString
public class RoleOut {

    String id;
    String name;
    String description;
    //
    Date createdTime;
    String createdBy;
    Date modifiedTime;
    String modifiedBy;
}
