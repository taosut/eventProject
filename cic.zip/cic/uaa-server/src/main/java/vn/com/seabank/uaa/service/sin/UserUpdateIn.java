package vn.com.seabank.uaa.service.sin;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.Date;

@Getter
@ToString
@Builder
public class UserUpdateIn {

    String id;
    //
//    String username;
    String email;
    boolean emailVerified;
    String mobileNumber;
    boolean mobileNumberVerified;
    boolean enabled;
    String nickname;
//    boolean credentialsNonExpired;
//    boolean accountNonExpired;
//    boolean accountNonLocked;
    String firstName;
    String lastName;
//    String avatar;
    Date birthday;
    String gender;
//    Collection<RoleOut> roles;
}
