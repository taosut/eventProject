//package vn.com.seabank.uaa.config;
//
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.*;
//
//@Configuration
//@EnableWebMvc
//public class WebMvcConfig implements WebMvcConfigurer {
//
//    @Override
//    public void addResourceHandlers(ResourceHandlerRegistry registry) {
//        registry.addResourceHandler(
//                "/resources/",
//                "/resources/**",
//                "/webjars/",
//                "/webjars/**",
//                "/image/**",
//                "/css/**",
//                "/js/**")
//                .addResourceLocations(
//                        "classpath:/resources/",
//                        "classpath:/webjars/",
//                        "classpath:/META-INF/resources/webjars/",
//                        "classpath:/static/image/",
//                        "classpath:/static/css/",
//                        "classpath:/static/js/");
//    }
//
//    @Override
//    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
//        configurer.enable();
//    }
//
//    @Override
//    public void addViewControllers(ViewControllerRegistry registry) {
//        registry.addViewController("/").setViewName("redirect:/index");
//        registry.addViewController("/index").setViewName("index");
//        registry.addViewController("/login").setViewName("login");
//    }
//
//
//
//}
