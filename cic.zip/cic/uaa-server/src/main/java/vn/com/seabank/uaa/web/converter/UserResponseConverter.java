package vn.com.seabank.uaa.web.converter;

import vn.com.seabank.uaa.service.sout.UserOut;
import vn.com.seabank.uaa.web.response.UserInfoResponse;
import vn.com.seabank.uaa.web.response.UserResponse;

import java.util.function.Function;

public class UserResponseConverter implements Function<UserOut, UserResponse> {

	@Override
	public UserResponse apply(UserOut user) {
		return  UserResponse.builder()
				.id(user.getId())
				.username(user.getUsername())
				.email(user.getEmail())
				.mobileNumber(user.getMobileNumber())
				.nickname(user.getNickname())
				.firstName(user.getFirstName())
				.lastName(user.getLastName())
				.birthday(user.getBirthday())
				.gender(user.getGender())
				.avatar(user.getAvatar())
				.build();
	}

}
