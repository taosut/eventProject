package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class UsernameDuplicateException extends ServiceBadException {

    public UsernameDuplicateException(String email) {
        super(String.format("Username %s is duplicated", email));
    }

    @Override
    public String getErrorCode() {
        return "USERNAME_DUPLICATE";
    }
}