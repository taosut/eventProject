package vn.com.seabank.uaa.exception;

import vn.com.seabank.core.exception.ServiceBadException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class UserPasswordNotMatchesException extends ServiceBadException {

    public UserPasswordNotMatchesException(String username) {
        super(String.format("Password of #%s is not match", username));
    }

    @Override
    public String getErrorCode() {
        return "PASSWORD_NOT_MATCH";
    }
}