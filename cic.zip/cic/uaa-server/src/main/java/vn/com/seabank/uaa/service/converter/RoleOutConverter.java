package vn.com.seabank.uaa.service.converter;

import vn.com.seabank.uaa.domain.Role;
import vn.com.seabank.uaa.service.sout.RoleOut;

import java.util.function.Function;

public class RoleOutConverter implements Function<Role, RoleOut> {


    @Override
    public RoleOut apply(Role role) {
        return RoleOut.builder()
                .id(role.getId())
                .name(role.getName())
                .description(role.getDescription())
//
                .createdBy(role.getCreatedBy())
                .createdTime(role.getCreatedTime())
                .modifiedBy(role.getModifiedBy())
                .modifiedTime(role.getModifiedTime())
                .build();
    }
}
