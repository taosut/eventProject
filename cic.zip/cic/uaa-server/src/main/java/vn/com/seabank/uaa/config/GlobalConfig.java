package vn.com.seabank.uaa.config;

import vn.com.seabank.web.filter.WebRequestTracingFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaAuditing
@EnableTransactionManagement(proxyTargetClass = true)
public class GlobalConfig  {



    @Bean
    public WebRequestTracingFilter webRequestTracingFilter() {
        return new WebRequestTracingFilter();
    }





}
