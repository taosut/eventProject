
INSERT INTO sec_user(id, username, password, enabled )
  VALUES ('1', 'admin', '{noop}123', true);

INSERT INTO sec_role(id, name)
  VALUES ('1', 'ROLE_ADMIN');

INSERT INTO sec_user_role(user_id, role_id)
  VALUES ('1', '1');


