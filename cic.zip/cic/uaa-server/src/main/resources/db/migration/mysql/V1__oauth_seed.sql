INSERT INTO `oauth_client_details` (`client_id`, `resource_ids`, `client_secret`, `scope`, `authorized_grant_types`, `web_server_redirect_uri`
                                    , `authorities`, `access_token_validity`, `refresh_token_validity`, `additional_information`, `autoapprove`)
VALUES
  ('app1', '', '123', 'read', 'password,authorization_code,refresh_token', '', '', NULL, NULL, '{}', ''),
  ('app2', '', '123', 'read', 'password,authorization_code,refresh_token', '', '', NULL, NULL, '{}', ''),
  ('app3', '', '123', 'read', 'implicit', '', '', NULL, NULL, '{}', 'read'),
  ('app4', '', '123', 'read', 'password,account_kit,facebook_login,google_login,refresh_token', '', '', NULL, NULL, '{}', 'read'),
  ('app5', '', '123', 'read', 'password,account_kit,facebook_login,google_login,refresh_token', '', '', 15, 150, '{}', 'read'),
  ('app6', '', '123', 'read', 'password,account_kit,facebook_login,google_login,refresh_token', '', '', 30, 300, '{}', 'read');


