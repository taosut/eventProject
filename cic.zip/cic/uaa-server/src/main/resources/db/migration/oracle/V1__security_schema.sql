-- DROP TABLE sec_role;

CREATE TABLE sec_role
(
  id VARCHAR(256) NOT NULL,
  name VARCHAR(256),
  description VARCHAR(1000),
  created_by VARCHAR(256),
  created_time TIMESTAMP,
  modified_by VARCHAR(256),
  modified_time TIMESTAMP,
  CONSTRAINT sec_role_pkey PRIMARY KEY (id),
  CONSTRAINT uk_328v0xhgur113t0ak61ieyp8n UNIQUE (name)
)


-- DROP TABLE sec_user;

CREATE TABLE sec_user
(
  id VARCHAR(256) NOT NULL,
  username VARCHAR(256),
  password VARCHAR(256),
  email VARCHAR(256),
  email_verified boolean,
  mobile_number VARCHAR(256),
  mobile_number_verified boolean,
  enabled boolean,
  nickname VARCHAR(256),
  first_name VARCHAR(256),
  last_name VARCHAR(256),
  avatar VARCHAR(500),
  gender VARCHAR(256),
  birthday date,
  created_by VARCHAR(256),
  created_time TIMESTAMP,
  modified_by VARCHAR(256),
  modified_time TIMESTAMP,
  CONSTRAINT sec_user_pkey PRIMARY KEY (id),
  CONSTRAINT uk_5ctbdrlf3eismye20vsdtk8w8 UNIQUE (username),
  CONSTRAINT uk_n49311ofc498xgnjl28jclyk9 UNIQUE (mobile_number),
  CONSTRAINT uk_numjsbs0wblvnqi7po8eyeo6y UNIQUE (email)
)


-- DROP TABLE sec_user_role;

CREATE TABLE sec_user_role
(
  user_id VARCHAR(256), NOT NULL,
  role_id VARCHAR(256), NOT NULL,
  CONSTRAINT fk835bbyiy6majrolcov7bp0yo0 FOREIGN KEY (user_id)
      REFERENCES sec_user (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fkfowkd8vw5qarh8b8y9noaf4et FOREIGN KEY (role_id)
      REFERENCES sec_role (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)