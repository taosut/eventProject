INSERT INTO oauth_client_details (client_id, resource_ids, client_secret, scope, authorized_grant_types, web_server_redirect_uri
                                    , authorities, access_token_validity, refresh_token_validity, additional_information, autoapprove)
VALUES
  ('app', '', '{noop}123', 'trust', 'implicit,authorization_code,password,account_kit,facebook,google,refresh_token', '', '', 300, 3000, '{}', 'trust');


