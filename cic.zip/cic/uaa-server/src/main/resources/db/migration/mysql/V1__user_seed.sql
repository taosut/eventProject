
INSERT INTO `user` (`username`, `password` , `status`)
VALUES
  ('test', '$2a$10$S29bfuGp2m6GCN9ZG3dHlO49AqZsR/lJMSkCwix17kDovqdF2MnGW', 'ACTIVE');



