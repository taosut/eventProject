CREATE TABLE user_ (
  id            bigserial not null,
  username      varchar(150),
  email         varchar(150),
  phone_number  varchar(15),
  password      varchar(255),
  nickname      varchar(150),
  avatar        varchar(255),
  status        varchar(50) NOT NULL,
  created_time  timestamp NULL,
  modified_time timestamp NULL,
  PRIMARY KEY (id));
COMMENT ON COLUMN   user_.status IS 'ACTIVE, BLOCKED, BANNED',


-- ALTER TABLE user_profile DROP FOREIGN KEY FKuser_profi696410;
CREATE TABLE user_profile (
  id            bigserial not null,
  user_id       bigint NOT NULL,
  first_name    varchar(50),
  last_name     varchar(50),
  birthday      date,
  gender        varchar(50),
  created_time  timestamp NULL,
  modified_time timestamp NULL,
  PRIMARY KEY (id));
-- ALTER TABLE user_profile ADD INDEX FKuser_profi696410 (user_id), ADD CONSTRAINT FKuser_profi696410 FOREIGN KEY (user_id) REFERENCES user_ (id);


CREATE TABLE role (
  id            bigserial not null,
  name          varchar(150) NOT NULL,
  title         varchar(150) NOT NULL,
  description   varchar(255),
  active        boolean DEFAULT true NOT NULL,
  created_time  timestamp NULL,
  modified_time timestamp NULL,
  PRIMARY KEY (id));


-- ALTER TABLE user_role DROP FOREIGN KEY FKuser_role943458;
-- ALTER TABLE user_role DROP FOREIGN KEY FKuser_role868982;
CREATE TABLE user_role (
  user_id bigint NOT NULL,
  role_id bigint NOT NULL,
  PRIMARY KEY (user_id,
  role_id));

-- ALTER TABLE user_role ADD INDEX FKuser_role943458 (user_id), ADD CONSTRAINT FKuser_role943458 FOREIGN KEY (user_id) REFERENCES user_ (id);
-- ALTER TABLE user_role ADD INDEX FKuser_role868982 (role_id), ADD CONSTRAINT FKuser_role868982 FOREIGN KEY (role_id) REFERENCES role (id);
