#  UAA - User Authentication and Authorize Server


## Build and Run
#Build 
```sh
mvn -X clean install
```

## Usage


### Login - Lấy access_token:

    ```sh
    curl -X POST -vu wap_app:123 http://localhost:7777/oauth/token -H "Accept: application/json" -d "password=123&username=loind&grant_type=password&scope=read%20write&client_secret=123&client_id=wap_app"
    ```

Cấu trúc JSON response khi login/lấy access_token thành công:

    ```json
        HTTP Status 200
        HTTP Response Body
        {
          "access_token": "ff16372e-38a7-4e29-88c2-1fb92897f558",
          "token_type": "bearer",
          "refresh_token": "f554d386-0b0a-461b-bdb2-292831cecd57",
          "expires_in": 43199,
          "scope": "read write"
        }
    ```
### Refresh access_token:
 ```sh
    curl -X POST -vu wap_app:123 http://localhost:7777/oauth/token -H "Accept: application/json" -d "grant_type=refresh_token&client_secret=123&client_id=wap_app&refresh_token=1faefef7-d725-492e-aa0e-d9f4ff5d260d"
 ```  
    
Note: sử dụng đúng client_id/client_secret khi lấy refresh_token trước đó 

### Để check token là valid or invalid(oauth/check_token  api):

    ```sh
    curl -X POST -vu http://localhost:7777/oauth/check_token -H "Accept: application/json" -d "token=ff16372e-38a7-4e29-88c2-1fb92897f558"
    ```

### User info - thông tin user 

    ```sh
    curl -X GET -vu http://localhost:7777/me -H "Accept: application/json" -H 'Authorization: Bearer ff16372e-38a7-4e29-88c2-1fb92897f558'
    ```


### Logout - invalid một token (oauth/expire api).

    ```sh
    curl -X DELETE -vu http://localhost:7777/me/logout -H 'Authorization: Bearer ff16372e-38a7-4e29-88c2-1fb92897f558' -d "token=ff16372e-38a7-4e29-88c2-1fb92897f558"
    ```


## Exceptions 

### /oauth/token : 
Sai client_id/client_secret (Basic Auth Fail):
  
        ```sh
            HTTP Status 401
            HTTP Response Body
            {
                "timestamp": 1506438041295,
                "status": 401,
                "error": "Unauthorized",
                "message": "Bad credentials",
                "path": "/oauth/token"
            } 
        ```

Sai user/pass:
 
            ```sh
            HTTP Status 400
            HTTP Response Body
            {
            "error": "invalid_grant",
            "error_description": "Bad credentials"
            } 
            ```
Trường grant_type không hợp lệ

            ```sh
                HTTP Status 400
                HTTP Response Body
                {
                "error": "unsupported_grant_type",
                "error_description": "Unsupported grant type: password"
                } 
            ```

