module.exports.pagination = {
  defaultRecordsCount: 50
}