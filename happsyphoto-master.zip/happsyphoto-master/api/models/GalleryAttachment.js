module.exports = {

  attributes: {
    gallery: {
      model: 'gallery'
    },
    attachment: {
      model: 'attachment'
    },
    order: {
      type: 'integer'
    }
  }
};