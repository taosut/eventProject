module.exports = {

  attributes: {
    attachment: {
      model: 'attachment',
      required: true
    }
  }
};