/**
 * Admin/UserController
 *
 * @description :: Server-side logic for managing Admin/users
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	/*create: function(req, res){
    var errors = new ErrorStorage();
    var userParams = {
      username : req.param('username'),
      password : req.param('password')
    }

    User.create(userParams).exec(function(err, user){
      if(err){
        var transformsErrors = errors.transformValidateErrors(err)
        return res.badRequest(transformsErrors)
      }

      req.logIn(user, function(err){
        return res.redirect('/happsyadmin');
      })
    })
  }*/
};

