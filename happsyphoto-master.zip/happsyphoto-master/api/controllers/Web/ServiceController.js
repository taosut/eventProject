module.exports = {
  show: function(req, res) {
    return res.view();
  }
}