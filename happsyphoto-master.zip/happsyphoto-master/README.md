# happsyphoto

a [Sails](http://sailsjs.org) application
# happsyphoto
